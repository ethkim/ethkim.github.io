/* This code obtained from Sean Alaric. Not entirely sure of it's true
 * orgin -- bgergel 
 */
#include<fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>

using namespace std;

inline unsigned int process_partition(unsigned char cache[],
                                      unsigned int offset,
                                      int max_row, bool show_primes, ostream& fout);
inline void print_row(unsigned char row, unsigned int offset, ostream& out);
inline void init_factors(unsigned int factors[][2]);
inline unsigned int sieve(unsigned int upper_bound, bool show_primes, ostream& fout);
void usage(const char *prog_name);

// upper limit on search
const unsigned int UPPER_BOUND = 4000000000U;

// Size of cache partitions (in bytes); should be chosen to take optimal
// advantage of cache memory
const int PAGE_SIZE      =  32768;

// Implied size of each block in cache (in integer value)
const int BLOCK_SIZE     = 30;

// Width of each row of cache (in bits)
const int ROW_SIZE       = 8;

// Number of rows in cache partition
const int PAGE_ROWS      = PAGE_SIZE / ROW_SIZE;

// Size of factors array; this is roughly
// (sqrt(UPPER_BOUND) / BLOCK_SIZE) * ROW_SIZE
const int FACTORS_SIZE   = 17472;

// Range of values effectively spanned by FACTOR_SIZE
const int FACTORS_RANGE  = (FACTORS_SIZE / ROW_SIZE) * BLOCK_SIZE;

// Range of each cache partition
const int PARTITION_SIZE = PAGE_SIZE * BLOCK_SIZE;

// Values to be added to partition and block offsets to create possible
// prime values
const int RESIDUALS[]    = {1, 7, 11, 13, 17, 19, 23, 29};

// Contains the column masks for each residual
const unsigned char COL_MASKS[]   = {static_cast<unsigned char>(0xfe),
                                     static_cast<unsigned char>(0xfd),
                                     static_cast<unsigned char>(0xfb),
                                     static_cast<unsigned char>(0xf7),
                                     static_cast<unsigned char>(0xef),
                                     static_cast<unsigned char>(0xdf),
                                     static_cast<unsigned char>(0xbf),
                                     static_cast<unsigned char>(0x7f)};

// Allows the proper index for COL_MASKS to be determined from the
// corresponding RESIDUAL
const int RESID_INDEX[]  = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 3, 0,
                            0, 0, 4, 0, 5, 0, 0, 0, 6, 0, 0, 0, 0, 0, 7};

// Contains the total number of bits that the index contains
const unsigned int BITS[] = { 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8 };

// -------------------------------------------------------------------
// main(int, char*[])
//
// Computes the primes from 1 to upper_bound using a variation of the
// Sieve of Eratosthenes; upper_bound must be specified by a command line
// argument no smaller than 1 and no greater than UPPER_BOUND
//
// If a third argument is present, all the primes found within the range
// will be printed; if not, only the number of primes found will be printed
//
// PRE:  upper_bound (1 <= upper_bound <= UPPER_BOUND) is specified on the
//           command line
//       a third argument to turn on printing may be specified on the command
//           line
// POST: primes from [1..UPPER_BOUND] are determined
//       if a third arguement was specified on the command line, lists each
//           prime found on standard output
//       else displays the number of primes found on standard output
// -------------------------------------------------------------------

int main(int argc, char *argv[])
{
        unsigned int  upper_bound = 0;
        bool          show_primes = false;
        char         *endptr = '\0';
	ofstream      fout;

        if ((argc < 2) || (argc > 3)) {
                usage(argv[0]);
                return EXIT_FAILURE;
        }

        upper_bound = strtoul(argv[1], &endptr, 10);
        if ((endptr == '\0') || (upper_bound > UPPER_BOUND)) {
                usage(argv[0]);
                return EXIT_FAILURE;
        }

        if (argc == 3)
	   if (argv[2] != '\0')
	   {
	      show_primes = true;
	      fout.open(argv[2]);
	   }
	   else
	   {
                        usage(argv[0]);
                        return EXIT_FAILURE;
	   }

        // Now that the command line has been parsed, the real work
        // begins...

        unsigned int count = sieve(upper_bound, show_primes, fout);

        // One final gasp...

        if (show_primes == false)
                cout << count << endl;

        return EXIT_SUCCESS;
}

// -------------------------------------------------------------------
// process_partition(unsigned char[], unsigned int, int, bool)
//
// Either prints the primes within the cache partition starting at
// offset or counts them up.
//
// PRE:  assigned all variables
// POST: if show_primes == true, all the primes within the partition are
//           printed to standard output
//       otherwise the primes are counted and the total returned
// -------------------------------------------------------------------

inline unsigned int process_partition(unsigned char cache[],
                                      unsigned int offset,
                                      int max_row, bool show_primes, ostream& fout)
{
        unsigned int count = 0;
        int          i;

        if (show_primes == false)
                for (i = 0; i < max_row; ++i)
                        count += BITS[cache[i]];
        else
                for (i = 0; i < max_row; ++i) {
                        print_row(cache[i], offset, fout);
                        offset += BLOCK_SIZE;
                }

        return count;
}

// -------------------------------------------------------------------
// print_row(unsigned char, unsigned int)
//
// Prints the numbers represented by the bits set in row according to
// BLOCK_SIZE, ROW_SIZE, and RESIDUALS[]
//
// PRE:  assigned row, offset
// POST: numbers represented by the bits set in row are printed to
//           standard output
// -------------------------------------------------------------------

inline void print_row(unsigned char row, unsigned int offset, ostream& out)
{
        int i;
        
        if (row == static_cast<unsigned char>(0xff))
                for (i = 0; i < ROW_SIZE; ++i)
                        out << offset + RESIDUALS[i] << '\n';
        else
                for (i = 0; i < ROW_SIZE; ++i)
                        if (row & ~COL_MASKS[i])
                                out << offset + RESIDUALS[i] << '\n';
}

// -------------------------------------------------------------------
// init_factors(unsigned int[][])
//
// Calculates all of the possible factors for nonprimes from 0 to
// sqrt(UPPER_BOUND) and places them into
// factors[0..FACTORS_SIZE - 1][0] and factors[0..FACTORS_SIZE - 1][1]
//
// PRE:  assigned factors[][], offset
// POST: factors[0..FACTORS_SIZE - 1][0] and factors[0..FACTORS_SIZE - 1][1]
//           contain all possible factors for
//           nonprimes within the range [0..sqrt(UPPER_BOUND)]
//           according to BLOCK_SIZE and ROW_SIZE
// -------------------------------------------------------------------

inline void init_factors(unsigned int factors[][2])
{
        unsigned int offset          = 0;
        int          current_block   = 0;
        int          i, j;

        for (i = 0; current_block < FACTORS_SIZE - 1; ++i) {
                for (j = 0; j < ROW_SIZE; ++j)
                        factors[current_block + j][0]         =
                                factors[current_block + j][1] =
                                offset + RESIDUALS[j];

                current_block += ROW_SIZE;
                offset        += BLOCK_SIZE;
        }
}

// -------------------------------------------------------------------
// sieve(unsigned int, bool)
//
// Finds all the primes between 1 and upper_bound, inclusive, by assigning
// zero to all composite indices of numbers[]
//
// PRE:  assigned upper_bound, show_primes
//       2 <= upper_bound <= UPPER_BOUND
// POST: if show_primes == true, all primes from [2..upper_bound] are printed
//           one per line to standard output
//       else the total number of primes from [2..upper_bound] is returned
// -------------------------------------------------------------------

inline unsigned int sieve(unsigned int upper_bound, bool show_primes, ostream& fout)
{
        unsigned int count = 0;

        if (upper_bound < 2)
                return count;

        // Might as well handle the special small cases now...

        if (show_primes == true) {
                if (upper_bound >= 2)
                       fout << "2\n";
                if (upper_bound >= 3)
                        fout << "3\n";
                if (upper_bound >= 5)
                        fout << "5\n";
        } else {
                if (upper_bound >= 2)
                        ++count;
                if (upper_bound >= 3)
                        ++count;
                if (upper_bound >= 5)
                        ++count;
        }

        if (upper_bound < 7)
                return count;

        int          i, j;
        unsigned int factors[FACTORS_SIZE][2];
        unsigned int partition_offset = 0;

        init_factors(factors);

        // Set up our bitfield cache to act as our sieve

        unsigned char cache[PAGE_SIZE];

        memset(cache, -1, PAGE_SIZE);
 
        // -------------------------------------------------------
        // We know that the first row of the bitfield should be set to this
        // value
        // -------------------------------------------------------

        cache[0] = static_cast<unsigned char>(0xfe);

        // ------------------------------------------------------------
        // This declaration sets the upper bound on the factors[][] array
        // ------------------------------------------------------------

        unsigned int max_factor;

        max_factor = static_cast<unsigned int>(sqrt((double)upper_bound));

        // Now to get down to business

        unsigned int product;
        unsigned int ceiling            = PARTITION_SIZE;
        unsigned int factor_offset      = 0;
        unsigned int cofactor_remainder = 0;
        int          row, col;

        // -----------------------------------------------------------------
        // We should always start with i == 1 to avoid sifting for multiples
        // of 1, and allow factors[][0] to overshoot max_factor a little bit
        // to force the loop to process the cache such that the partition it
        // contains on exit *always* contains the upper_bound (it can fall
        // just short otherwise)
        // -----------------------------------------------------------------

        i = 1;

        while (factors[i - 1][0] <= max_factor) {
                product = factors[i][0] * factors[i][0];

                // -------------------------------------------------------
                // If the square of the current factor is greater than our
                // current ceiling, we know it's time to process the cache
                // and start a new partition
                // -------------------------------------------------------

                if (product >= ceiling) {
                        count += process_partition(cache, partition_offset,
                                                   PAGE_SIZE, show_primes, fout);
                        memset(cache, -1, PAGE_SIZE);                   
                        partition_offset =  ceiling;
                        ceiling          += PARTITION_SIZE;
                        i = 1;
                        continue;
                }

                // -------------------------------------------------------
                // Since we can't keep all possible factors in memory, each
                // element of factors[][0] keeps track of the factor it needs
                // to be multiplied by next in factors[][1].  Calculating this
                // is a little subtle, but not too bad.
                // -------------------------------------------------------

                product            = factors[i][0] * factors[i][1];
                cofactor_remainder = (factors[i][1] % FACTORS_RANGE);
                factor_offset      = factors[i][1] - cofactor_remainder;
                j                  = ((cofactor_remainder / BLOCK_SIZE) *
                      ROW_SIZE) + RESID_INDEX[cofactor_remainder % 30] - 1;

                while ((product < ceiling) && (product <= upper_bound)) {
                        product    -= partition_offset;
                        row        =  product / BLOCK_SIZE;
                        col        =  product % BLOCK_SIZE;
                        cache[row] &= COL_MASKS[RESID_INDEX[col]];

                        // ------------------------------------------
                        // Now we need to calculate the next cofactor
                        // ------------------------------------------

                        ++j;
                        if ((j < FACTORS_SIZE) == false) {
                                factor_offset += FACTORS_RANGE;
                                j = 0;
                        }
                        factors[i][1] = factor_offset + factors[j][0];
                        product       = factors[i][0] * factors[i][1];
                }
                ++i;
        }

        // -------------------------------------------------------
        // Make sure we pull the max_row up to the upper_bound
        // -------------------------------------------------------

        int max_row = (upper_bound / BLOCK_SIZE) % PAGE_SIZE;
        int max_col = upper_bound % BLOCK_SIZE;

        // -------------------------------------------------------
        // Since max_square may not fit in our sieve, we need to
        // compensate.  If max_col == 0, then we know we don't
        // need to look at the row at all.
        //
        // This gets subtle.  Beware.
        // -------------------------------------------------------

        if (max_col != 0) {

                // -------------------------------------------------------
                // If max_col lands on a valid bit (meaning
                // RESID_INDEX[max_col] != 0) we want to skip over it;
                // if not, we want to begin blotting out from the next
                // valid bit; this is why we increment max_col right away
                // -------------------------------------------------------

                ++max_col;
                while ((RESID_INDEX[max_col] == 0) && (max_col < BLOCK_SIZE))
                        ++max_col;

                // -------------------------------------------------------
                // Blot out the remaining bits in the last row, if any, and
                // increment max_row to provide for the new boundary
                // -------------------------------------------------------

                if (max_col < BLOCK_SIZE) {
                        for (i = RESID_INDEX[max_col]; i < ROW_SIZE; ++i)
                                cache[max_row] &= COL_MASKS[i];
                }
                ++max_row;
        }

        // Now we sift through and see what we can find

        count += process_partition(cache, partition_offset, max_row,
                                   show_primes, fout);
        return count;
}

// -------------------------------------------------------------------
// usage(const char *)
//
// Prints a usage message for proper invocation of the program
//
// PRE:  program is not invoked properly
// POST: usage message is printed to standard output
// -------------------------------------------------------------------

void usage(const char *prog_name)
{
        cout << "Usage: " << prog_name << " <upper_limit> [--show]\n\n"
             << "\t<upper_limit>\trequired upper-bound for the search\n"
             << "\t\t\t(1 <= upper_limit <= " << UPPER_BOUND << ")\n"
             << "\t--show\t\tspecify that all primes found should be printed\n"
             << "\t\t\t(number found printed otherwise)"
             << endl;
}

// End of sieve.cc
