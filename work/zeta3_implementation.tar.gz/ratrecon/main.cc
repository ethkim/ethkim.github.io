#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;

#include <gmpxx.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "poly.h"
#include "convseries.h"
#include "readconf.h"

#define NUM_PRIMES 100000

int inc_stacksize(void) 
{
 	 struct rlimit limit;
  	int ret;
  	if(getrlimit(RLIMIT_STACK, &limit)< 0) {
    	printf("getrlimit error\n");
    	return -1;
  	}
  	limit.rlim_cur = RLIM_INFINITY;
  	limit.rlim_max = RLIM_INFINITY; 
  	ret = setrlimit(RLIMIT_STACK, &limit);
  	printf("setrlimit=%d\n", ret);
  	return 0;
}

int main (int argc, char * const argv[]) 
{
  	//clock_t begin, end;
  	vector<Polynomial> x;
  	ReadConfig test2;
  	mpz_class T;
  	if(argc != 2) {
    	printf("you have to specify the number of digits\n");
    	exit(1);
  	}
    
  	inc_stacksize();

  	test2.readFile("input.dat");
  	test2.getPoly(x);
  	ConvSeries series(x,3.0102348);
  	// series.printPoly();
  	int bdigit;
  	bdigit = atoi(argv[1]);

  	series.evaluate(bdigit);

  	return 0;
}

