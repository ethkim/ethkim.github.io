// $Log: result.cpp,v $
// Revision 1.2  2004/08/03 19:27:41  bgergel
// commit comments now added to each file
//
#include <iostream>
using namespace std;

#include <gmpxx.h>
#include "result.h"

Result::Result() : T(0),P(0),Q(0)
{
}

Result::Result(Result &copy)
{
  	T = copy.T;
  	P = copy.P;
  	Q = copy.Q;
}

Result::Result(mpz_class &t,mpz_class &p,mpz_class &q)
{
  	T = t;
  	P = p;
  	Q = q;
}

Result &Result::operator= (const Result &copy)
{
  	if(this != &copy) {
      	T = copy.T;
      	P = copy.P;
      	Q = copy.Q;
    }
  	return *this;
}

