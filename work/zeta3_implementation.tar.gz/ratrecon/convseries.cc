// $Log: convseries.cpp,v $
// Revision 1.13  2004/08/04 20:44:50  ekim
//
// changes made to poly and summodp
//
// Revision 1.12  2004/08/04 17:43:15  ekim
// *** empty log message ***
//
// Revision 1.11  2004/08/04 16:16:25  bgergel
//
// Updated CR with reset for polynomials
//
// Revision 1.10  2004/08/04 16:15:19  ekim
//
// Fixing CR and summodp in progress
//
// Revision 1.9  2004/08/03 21:11:19  bgergel
// removed CR testing code
//
// Revision 1.8  2004/08/03 20:40:05  bgergel
// CR testing
//
// Revision 1.7  2004/08/03 20:28:46  ekim
// *** empty log message ***
//
// Revision 1.6  2004/08/03 20:20:11  ekim
//
// Changes made to all the garbage functions.
//
// Revision 1.5  2004/08/03 19:55:24  bgergel
//
// - removed all reference to polynomial B - it's not required anymore
// - removed multiple versions of split and evaluate functions - now only
//   uses code without B for binary splitting
// - removed unneeded functions and old checkpointing code
//
// Revision 1.4  2004/08/03 19:39:04  bgergel
//
// - removed result class from converseries into seperate file
// - fixed up Makefile and added build for result class
//
// Revision 1.3  2004/08/03 19:27:41  bgergel
// commit comments now added to each file
//

#include <iostream>
#include <cstdio>
#include <vector>
#include <cstdio>
#include <cmath>
#include <cassert>
//#include <sstream>
#include <fstream>
using namespace std;

#include <unistd.h>
#include <sys/resource.h>
#include <gmpxx.h>

#include "result.h"
#include "poly.h"
#include "convseries.h"
#include "util.h"

#define DIGITS_PER_TERM 3.0102348

//mpz_class ConvSeries::prime = 0;

ConvSeries::ConvSeries()
{
  dpt = 0;
  bpd = 3.32192809488736234787;
}

ConvSeries::ConvSeries(vector<Polynomial> &p,double d)
{
  bpd = 3.32192809488736234787;
  
  dpt = d;	
  baseA = p[0];
  // this constructor assumes either 3 or 4 polynomials have been passsed in
  baseP = p[1];
  baseQ = p[2];
}

ConvSeries::ConvSeries(Polynomial &a,Polynomial &p,Polynomial &q,double d)
{
  bpd = 3.32192809488736234787;
	
  dpt = d;
  baseA = a;
  baseP = p;
  baseQ = q;
}


ConvSeries::~ConvSeries()
{
}

void ConvSeries::evaluate(const long precision)
{
  	long terms;
  	mpz_class S,answer,m,tq;
  	Result rt;
  	int bnd,G;
	struct rusage time[10];
	ofstream file_out;
	
	file_out.open("zeta-result");
	if(file_out.fail())
	{
		cout << "Unable to open file result\n";
		exit(1);
	}

  	terms = (long)(precision/dpt) + 1;
  	cout << "=====================================\n";
  	cout << "Time profile for:\n";
  	cout << "digits:" << precision << endl;
  	cout << "terms:" << terms << endl;
  	cout << "result:\n";
	
  	cout.setf(ios::fixed);
  	cout.setf(ios::showpoint);
  	cout.precision(2);

	getrusage(RUSAGE_SELF, time + 9);

  	// bound
  	bnd = bound(terms);
	getrusage(RUSAGE_SELF, time + 0);
	cout << "bound Time: " << get_elapsed(time[9], time[0]) << endl;
   	//cout << "Bound: " << bnd << endl << endl; 
	
	long n = (long)generate_m_primes(m,bnd);
	getrusage(RUSAGE_SELF, time + 1);
	cout << "generate m primes Time: " << 
		get_elapsed(time[0], time[1]) << endl;
   	//cout << "m:\n" << m << endl << endl;
	
	long s = 0, i = 0;
	split_m_primes(m,s,n,i);
	getrusage(RUSAGE_SELF, time + 2);
	cout << "generate m Time: " << 
		get_elapsed(time[1], time[2]) << endl;
	delete_m_primes();

  	// find G
	G = group(terms,m);
	getrusage(RUSAGE_SELF, time + 3);
	cout << "group Time: " << get_elapsed(time[2], time[3]) << endl;
  	//cout << "G: " << G << endl << endl;

  	// summodm
  	summodm(tq,G,terms,m);
	getrusage(RUSAGE_SELF, time + 4);
	cout << "summodm Time: " << get_elapsed(time[3], time[4]) << endl;
   	//cout << "tq:\n" << tq << endl << endl;
	
  	//  ratrecon
  	ratRecon(tq,m);
	getrusage(RUSAGE_SELF, time + 5);
	cout << "ratrecon Time: " << get_elapsed(time[4], time[5]) << endl;

  	mpz_class base, exp;
  	base = 10;
  	mpz_pow_ui(exp.get_mpz_t(),base.get_mpz_t(),(precision));
  	num *= exp;
  	mpz_fdiv_q(tq.get_mpz_t(),num.get_mpz_t(),denom.get_mpz_t());
	getrusage(RUSAGE_SELF, time + 6);
	cout << "final division Time: " << get_elapsed(time[5], time[6]) << endl;
	
	cout << "Total Time: " << get_elapsed(time[9], time[6]) << endl;
  	file_out << "Result:" << endl << tq / 2 << endl << endl;
	file_out.close();
}

void ConvSeries::split(Result &r,long n1,long n2)
{
	Result t;
  	int i, diff;
	
  	diff = n2 - n1;
  	assert(diff != 0);
  	if(diff <= 5) {
      	for(i = 0; i < diff; i++) {
	  		baseP.evaluateCR(n1 + i, t.P);
	  		baseQ.evaluateCR(n1 + i,t.Q);
	  		baseA.evaluateCR(n1 + i, t.T);
	  		t.T *= t.P;
	  		//now merge
	  		if(i == 0) {
	    		r = t;
	  		}else {
	      		r.Q *= t.Q;
	      		r.T *= t.Q;
	      		t.T *= r.P;
	      		r.P *= t.P;
	      		r.T += t.T;
	    	}
		}		
    }else {
		int nm=(n1+n2)/2;
		split(r, n1, nm);
		split(t, nm, n2);
	    
		r.Q *= t.Q;
		r.T *= t.Q;
		t.T *= r.P;
		r.P *= t.P;
		r.T += t.T;
	}
}

void ConvSeries::postSplit(const mpz_class &S, mpz_class &answer)
{
  // this is specific to calculating Zeta(3) - this is the constant
  answer = S / 2;
}

void ConvSeries::finalDiv(Result &rt,const long prec, mpz_class &S)
{
  mpz_class BQ, T;
  mpz_class B, Q;
  
  BQ = rt.Q;
  
  T = rt.T; 
  B = 10;
  mpz_pow_ui(Q.get_mpz_t(), B.get_mpz_t(), prec); //Q holds 10^digits
  mpz_mul(T.get_mpz_t(), T.get_mpz_t(), Q.get_mpz_t()); //T holds T*(10^digits)
  mpz_fdiv_q(S.get_mpz_t(), T.get_mpz_t(), BQ.get_mpz_t());	
}

void ConvSeries::printPoly()
{
  cout << "***********************************************************************\n";
  cout << "The polynomials are:\n";
  cout << baseA << endl << baseP << endl << baseQ << endl;
  cout << "***********************************************************************\n";
}

//calculates the sum mod p for chinese remainder
mpz_class ConvSeries::summodp(int n2, mpz_class p) 
{
	Result r;
	mpz_class bqinv;
  	mpz_class pT, pP, pQ;

  	baseP.findFirstRowCR(0, r.P, p);
  	baseQ.findFirstRowCR(0, r.Q, p);
  	baseA.findFirstRowCR(0, r.T, p);

  	pP = r.P;
  	pQ = r.Q;
  	pT = r.T * pP;
  	mpz_mod(pT.get_mpz_t(), pT.get_mpz_t(), p.get_mpz_t());

  	baseP.findFirstRowCR(1, r.P, p);
  	baseQ.findFirstRowCR(1, r.Q, p);
  	baseA.findFirstRowCR(1, r.T, p);
  
  	pP *= r.P;
  	mpz_mod(pP.get_mpz_t(), pP.get_mpz_t(), p.get_mpz_t());
  	pQ *= r.Q;
  	mpz_mod(pQ.get_mpz_t(), pQ.get_mpz_t(), p.get_mpz_t());
  	pT *= r.Q;
  	pT += pP * r.T;
  	mpz_mod(pT.get_mpz_t(), pT.get_mpz_t(), p.get_mpz_t());
  
  	int i;
  	for(i = 2; i < n2; i++) {
    	baseP.evaluateCR(i, r.P, p);
    	baseQ.evaluateCR(i, r.Q, p);
    	baseA.evaluateCR(i, r.T, p);

    	pP *= r.P;
    	mpz_mod(pP.get_mpz_t(), pP.get_mpz_t(), p.get_mpz_t());
    	pQ *= r.Q;
    	mpz_mod(pQ.get_mpz_t(), pQ.get_mpz_t(), p.get_mpz_t());
    	pT *= r.Q;
    	pT += pP * r.T;
    	mpz_mod(pT.get_mpz_t(), pT.get_mpz_t(), p.get_mpz_t());
  	}

  	//compute T(Q^(-1)) mod P here
  	mpz_invert(bqinv.get_mpz_t(), pQ.get_mpz_t(), p.get_mpz_t());
  	pT *= bqinv;
  	return pT % p;
}

mpz_class ConvSeries::crt(int n, mpz_class *a, mpz_class *m) 
{
  	int k, i;
  	mpz_class prod, gcd, temp, x;
  	mpz_class* gamma = new mpz_class[n];
  	mpz_class* v = new mpz_class[n];
  
  	for(k = 1; k < n; k++) {
    	mpz_mod(prod.get_mpz_t(), m[0].get_mpz_t(), m[k].get_mpz_t());
    	for(i = 1; i < k; i++) {
      		prod = prod * m[i];
      		mpz_mod(prod.get_mpz_t(), prod.get_mpz_t(), m[k].get_mpz_t());
    	}
    	mpz_invert(gamma[k].get_mpz_t(), prod.get_mpz_t(), m[k].get_mpz_t());
  	}

  	/*compute coefficients*/
  	v[0] = a[0];
  	for(k = 1; k < n; k++) {
		temp = v[k-1];
    	for(i = k - 2; i >= 0; i--) {
      		temp = (temp * m[i]);
      		mpz_mod(temp.get_mpz_t(), temp.get_mpz_t(), m[k].get_mpz_t());
      		temp += v[i];
      		mpz_mod(temp.get_mpz_t(), temp.get_mpz_t(), m[k].get_mpz_t());
      		if(temp < 0) {
				temp += m[k];
      		}
    	}
    	temp = ((a[k]-temp));
    	mpz_mod(temp.get_mpz_t(), temp.get_mpz_t(), m[k].get_mpz_t());
    	temp *= gamma[k];
    	mpz_mod(v[k].get_mpz_t(), temp.get_mpz_t(), m[k].get_mpz_t());
    	if(v[k] < 0) {
      		v[k] += m[k];
    	}
  	}
  
  	/*convert from mixed-radix rep*/
  	x = v[n - 1];
  	for(k = n - 2; k >= 0; k--) {
    	x = x * m[k] + v[k];
  	}
  
  	delete []gamma;
  	delete []v;
  	return x;
}

void ConvSeries::ratRecon(const mpz_class &g, const mpz_class &M) 
{
  	int sign = 1;
  	mpz_class halfM, sqrtM;
  	halfM = (M - 1) / 2;
  	mpz_sqrt(sqrtM.get_mpz_t(), M.get_mpz_t());
  
  	mpz_class r0, r1, r2, s0, s1, s2, t0, t1, t2, q;
  
  	r0 = M; s0 = 1; t0 = 0;
  	r1 = g; s1 = 0; t1 = 1;

  	if(halfM < g) {
    	r1 = M - g;
    	sign = -1;
  	}

  	while(!(r1 < sqrtM)) {
    	mpz_fdiv_q(q.get_mpz_t(), r0.get_mpz_t(), r1.get_mpz_t());
    	mpz_mod(r2.get_mpz_t(), r0.get_mpz_t(), r1.get_mpz_t());
    	s2 = s0 - q * s1;
    	t2 = t0 - q * t1;
    	r0 = r1; r1 = r2;
    	s0 = s1; s1= s2;
    	t0 = t1; t1 = t2;
  	}
  	num = r1;
  	denom = t1;

  	if (sign == -1) {
   	 	num *= -1;
  	}
  	reduce();
  
  	if(!ratReconCheck(g,M)) {
    	q = (r0 - sqrtM) / r1 + 1;
    	mpz_class rs = r0 - q * r1;
    	mpz_class ts = t0 -q * t1;
    	num = rs;
    	denom = ts;
    	if(sign == -1) {
      		num *= -1;
    	}
    	reduce();
  	}
  	assert(ratReconCheck(g, M));
//   cout<<"num:"<<num<<endl;
//   cout<<"denom:"<<denom<<endl;
}

void ConvSeries::reduce() 
{
  	mpz_class g;
  	mpz_gcd(g.get_mpz_t(), num.get_mpz_t(), denom.get_mpz_t());
  	num /= g;
  	denom /= g;
  	if(denom < 0) {
    	num *= -1;
    	denom *= -1;
  	}
}

bool ConvSeries::ratReconCheck(const mpz_class &g, const mpz_class &M) 
{
  	mpz_class inverse, gcd, mod;
  	mpz_invert(inverse.get_mpz_t(), denom.get_mpz_t(), M.get_mpz_t());
  	mpz_gcd(gcd.get_mpz_t(), denom.get_mpz_t(), M.get_mpz_t());
  	inverse *= num;
  	mpz_mod(mod.get_mpz_t(), inverse.get_mpz_t(), M.get_mpz_t());
  	return (mod == g && gcd == 1);
}

void ConvSeries::resetPolynomials()
{
  	baseA.resetCR();
  	baseP.resetCR();
  	baseQ.resetCR();
}

int ConvSeries::bound(int n) 
{
  	int *primes = new int[2*n];
  	int i, p, m;
  	double sizeT;
  	FILE *fp;
  	fp = fopen("prime.dat", "r"); //Assuming prime.dat holds all the primes upto 2*n.
  	for(i = 0; i < 2 * n; i++) {
    	fscanf(fp, "\n%d\n", &primes[i]);
  	}
  	fclose(fp);
  	if(primes[i - 1] < 2 * n) {
    	printf("We don't have enough primes in prime.dat file!\n");
    	exit(1);
  	}
  	sizeT = 15 + 5 * floor( (log((double)n - 1) / log((double)2) ) );
//   cout << "sizeT = " << sizeT << endl;
  	m = 2 * n - 2;
  	n *= 2;
  	for(i = 1; (p = primes[i]) < n; i++) {
    	//log(p) * (5 log[p](2n-2) )
    	sizeT += (5 * (log((double)m) / log((double)2)));
//     	cout << "sizeT = " << sizeT << endl;
   	}

  	sizeT = ceil(sizeT*(log((double)2)/log((double)10)));
  
  	delete []primes;
  	return (int)sizeT;
}

void ConvSeries::split_m_primes(mpz_class &result, long l, long r, long &i)
{
	long mid;

	if((r - l) == 1) {
		//mpz_nextprime(prime.get_mpz_t(),prime.get_mpz_t());
		result = mPrimes[i++];
	}else {
	    mpz_class right;
		mid = (r + l) / 2;
		split_m_primes(result,l,mid,i);
		split_m_primes(right,mid,r,i);
		result *= right;
	}
}

unsigned long ConvSeries::generate_m_primes(mpz_class &m, long digits)
{
	unsigned long n;
	unsigned long size;
	mpz_class prime;

	// generate the prime to start at 
	// p_0 > q(n) to insure P is relatively prime to Q
	baseQ.evaluateHorner(digits,prime);
	mpz_nextprime(prime.get_mpz_t(),prime.get_mpz_t());

	// get size of p_0 here
	size = mpz_sizeinbase(prime.get_mpz_t(),10) - 1;

	// calculate n - we need to know how many primes to use
	n = ((2 * digits) + 3) / size + 1;

	// Generate mPrimes
	mPrimes = new mpz_class[n];
	mPrimes[0] = prime;
	for(int i = 1; i < (signed long)n; i++)
		mpz_nextprime(mPrimes[i].get_mpz_t(),mPrimes[i - 1].get_mpz_t());
	//split_m(m,0,n);
	return n;
}

void ConvSeries::delete_m_primes()
{
	delete [] mPrimes;
}

void ConvSeries::summodm(mpz_class &tq,unsigned long G, unsigned long n,mpz_class &m)
{
	Result total;
	unsigned long start,end;
	mpz_class pt,bqinv;

	// humbly modified on suggestion from howard
	total.T = 0;
	total.P =  total.Q = 1;

	start = 0;
	end = G;
	while( start < n)
	{
		Result r;
		split(r,start,end); // use the reg binsplit code to do the splitting

		// combine the results - this needs to be modulo m?
        total.T *= r.Q;
		r.T *= total.P;
		total.T += r.T;
		mpz_mod(total.T.get_mpz_t(),total.T.get_mpz_t(),m.get_mpz_t());
		total.P *= r.P;
		mpz_mod(total.P.get_mpz_t(),total.P.get_mpz_t(),m.get_mpz_t());
		total.Q *= r.Q;
		mpz_mod(total.Q.get_mpz_t(),total.Q.get_mpz_t(),m.get_mpz_t());
		start = end;
		end += G;
		if( end >= n)
			end = n;
	}

	// TQ^-1 needs to be calculated here
	// ask ethan how do this correctly
  	mpz_invert(bqinv.get_mpz_t(),total.Q.get_mpz_t(),m.get_mpz_t());
  	tq = total.T;
  	tq *= bqinv;
    mpz_mod(tq.get_mpz_t(), tq.get_mpz_t(), m.get_mpz_t());
}

int ConvSeries::group(unsigned long n, mpz_class& m) 
{
  	mpz_class m_amax, logm, logqmax,  res, ghi, glo, gmid;
  	int hi, lo, mid;

  	mpz_class amax,qmax;
  	baseA.evaluateHorner(n-1,amax);
  	baseQ.evaluateHorner(n-1,qmax);

  	logm = mpz_sizeinbase(m.get_mpz_t(),2);
  	logqmax = mpz_sizeinbase(qmax.get_mpz_t(),2);
  	logqmax -= 1;
  	mpz_fdiv_q(res.get_mpz_t(), logm.get_mpz_t(), logqmax.get_mpz_t());
  	hi =mpz_get_ui(res.get_mpz_t()) + 1;
  
  	m_amax = m / amax;
  	//now find the largest g such that g*qmax^g < m_amax
  	lo = 1;
  	mpz_pow_ui(res.get_mpz_t(), qmax.get_mpz_t(), lo);
  	glo = lo * res;
  	mpz_pow_ui(res.get_mpz_t(), qmax.get_mpz_t(), hi);
  	ghi = hi * res;
//   cout<<"amax:"<<amax<<" qmax:"<<qmax<<endl;
//   cout<<"glo:"<<glo<<endl<<" m_amax"<<m_amax<<endl;
  	if(glo > m_amax) {
    	cout << "there is no such g\n";
    	return -1;
  	}else if(ghi < m_amax) {
    	return hi;
  	}

  	while(lo + 1 < hi) {
    	mid = (lo + hi) / 2;
    	mpz_pow_ui(res.get_mpz_t(), qmax.get_mpz_t(), mid);
    	gmid = mid * res;
    	if(gmid < m_amax) {
      		lo = mid;
    	}else{
      		hi = mid;
    	}
  	}
  	return lo;
}

