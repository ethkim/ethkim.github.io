// $Log: convseries.h,v $
// Revision 1.9  2004/08/04 17:43:15  ekim
// *** empty log message ***
//
// Revision 1.8  2004/08/04 16:16:25  bgergel
//
// Updated CR with reset for polynomials
//
// Revision 1.7  2004/08/03 19:55:24  bgergel
//
// - removed all reference to polynomial B - it's not required anymore
// - removed multiple versions of split and evaluate functions - now only
//   uses code without B for binary splitting
// - removed unneeded functions and old checkpointing code
//
// Revision 1.6  2004/08/03 19:39:04  bgergel
//
// - removed result class from converseries into seperate file
// - fixed up Makefile and added build for result class
//
// Revision 1.5  2004/08/03 19:27:41  bgergel
// commit comments now added to each file
//

#ifndef CONVSERIES_H_
#define CONVSERIES_H_

#include <vector>
using namespace std;

#include <gmpxx.h>
#include "poly.h"
#include "result.h"

class ConvSeries
{
private:
	//static mpz_class prime;
	double dpt; // Digits Per Term
	double bpd; // Bits Per Digit
	Polynomial baseA;
	Polynomial baseP;
	Polynomial baseQ;
	mpz_class num, denom;
	mpz_class *mPrimes;
	
	// Operation Functions not exposed to outside world
	void split(Result&, long, long);
	void postSplit(const mpz_class&, mpz_class&);
	void finalDiv(Result&,const long, mpz_class&);

	int bound(int);
	void split_m_primes(mpz_class&, long, long, long&);
	unsigned long generate_m_primes(mpz_class&, long);
	void delete_m_primes();
	void summodm(mpz_class&, unsigned long, unsigned long, mpz_class&);
	int group(unsigned long, mpz_class&);
	void ratRecon(const mpz_class&, const mpz_class&);
	void reduce();
	bool ratReconCheck(const mpz_class&, const mpz_class&);

	mpz_class summodp(int, mpz_class);
	mpz_class crt(int, mpz_class*, mpz_class*);
	void resetPolynomials();
	
public:
	// Constructors and Destructors
	ConvSeries();
	ConvSeries(vector<Polynomial>&, double);
	ConvSeries(Polynomial&, Polynomial&, Polynomial&, double);
	~ConvSeries();
	
	// Operation Functions
	void evaluate(const long);
	void printPoly();
};

#endif

