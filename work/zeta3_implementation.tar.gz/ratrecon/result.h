// $Log: result.h,v $
// Revision 1.3  2004/08/03 19:27:41  bgergel
// commit comments now added to each file
//

#ifndef RESULT_H_
#define RESULT_H_

class Result
{
public:
	mpz_class T;
	mpz_class P;
	mpz_class Q;
	
	Result();
	Result(Result&);
	Result(mpz_class&,mpz_class&,mpz_class&);
	Result &operator= (const Result&);
};

#endif

