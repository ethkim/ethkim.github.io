// ****** NOTE **********
// This code is borrowed from Howard's and Alex's work at Waterloo. Only the
// rusage code has been retained in this copy of the file
// ****** NOTE **********

// vim: tw=80 cindent
//
// Utility functions for zeta3 computation
//
// Howard Cheng
//
// $Log: util.h,v $
// Revision 1.1.1.1  2004/08/03 03:40:45  bgergel
//
// Storing Alex and Howard's code on cvs - initial creation of code sent to
// bgergel by hcheng.
//
// Revision 5.7  2004/06/29 23:53:23  am2stewa
// Don't mix signal(2) (BSD-lineage) with sigsuspend (POSIX). Standardize on
// POSIX.
//
// Add debugging output for timings of different processes.
//
// Tell the memory monitor about a few new steps.
//
// Revision 5.6  2004/06/01 22:07:10  am2stewa
// First pass at multi-process computation.
// Currently only implemented when using pure-gmp (representation 2).
//
// Revision 5.5  2004/01/15 05:16:48  am2stewa
// Implement skipping some values of the polynomial, also called advancement.
//
// Revision 5.4  2003/07/23 20:33:44  am2stewa
// Add a function, cleaner_exit, that handles clean-up as well.  For now,
// clean-up means destructing MemHelper so that the child is killed.
//
// Revision 5.3  2003/07/18 17:47:14  am2stewa
// Added support for writing the T and Q to a file, as well as forking a
// process to monitor our memory usage.
//
// Revision 5.2  2003/07/09 23:36:52  am2stewa
// Decent checkpointing support.  Both representations work and have been
// tested to compute zeta(3) to 10000 digits.
//
// Revision 5.1  2003/06/25 16:10:54  am2stewa
// Initial checkpointing checkin.  Only the Standard Representation works, and
// only tested with one checkpoint and no checkpoints.  Some architectural
// work left, but the main jobs left are code-cleanup and getting Our
// Representation working.
//
// Revision 4.6  2003/06/18 20:20:34  am2stewa
// Two clean-ups
// * Rather than have t1, t2, t3, t4, there's just time[4]
// * {load,save}State are now {load,save}PolyState, since there's more to
//   state that the chain of recurrences
//
// Revision 4.5  2003/06/16 22:59:04  am2stewa
// Add a new command-line parameter, --truncate, that will undo the rounding
// of the mpf_t when it's printed.  This is important for checkpointing, since,
// if we round-up, the next delta will be negative!  I wish there was a way
// to just tell gmp_*printf that we don't want the rounding!
//
// Revision 4.4  2003/06/16 20:07:48  am2stewa
// Made _DISPLAY_ into --display, so that I wouldn't have to recompile the
// program every time I wanted to change it.
//
// Revision 4.3  2003/06/11 22:14:14  am2stewa
// Besides miscellaneous fixes, the important change is that the code to
// compute the values of the leaves of the binary splitting tree has been
// removed from zeta.cc and is now automatically generated based on the
// unrolling factor.
//
// This code has been tested to compute zeta(3) to 2000000 digits in 245.37
// seconds, and the result has been confirmed by comparing to
// Zeta3-2million.txt.gz.
//
// Revision 4.2  2003/05/15 19:30:41  am2stewa
// Replaced the user-configurable factors_out with a user-configurable
// preallocate.
//
// Revision 4.1  2003/05/13 20:26:03  am2stewa
// Now using GMP, with the PVM code disabled.
//
// Revision 1.1  1999/12/18 01:29:06  hchcheng
// Initial revision
//
//

#ifndef _UTIL_H_
#define _UTIL_H_

#include <stdio.h>
#include <gmpxx.h>
#include <ostream>

void rusage_add(struct rusage &dest, struct rusage &op1, struct rusage &op2);
void rusage_sub(struct rusage &dest, struct rusage &op1, struct rusage &op2);
double get_elapsed(struct rusage start, struct rusage end);
void check_results(const mpz_class &T1, const mpz_class T2, 
		   const mpz_class &Q1, const mpz_class Q2);
std::ostream &operator<<(std::ostream &s, struct rusage &used);
#endif
