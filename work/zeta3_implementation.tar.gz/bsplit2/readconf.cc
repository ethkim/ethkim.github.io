// $Log: readconf.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
#include <vector>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cctype>
using namespace std;

#include "poly.h"
#include "readconf.h"

#define LINEMAX 128
#define MAXARGS 256

ReadConfig::ReadConfig()
{
	poly.reserve(10);
	dpt = 0;
}

ReadConfig::~ReadConfig()
{
}

double ReadConfig::getDpt()
{
	return dpt;
}

void ReadConfig::getPoly(vector<Polynomial> &a) const
{
	int size = (int)poly.size();
	
	a.clear();
	for(int i = 0; i < size;i++)
		a.push_back(poly[i]);
}

void ReadConfig::readFile(const char *filename)
{
	ifstream input;
	int stage = 0;
	vector<int> p1,b1;
	char temp[LINEMAX];
	
	input.open(filename);
    if(input.fail())
    {
        cout << "Unable to open the datafile " << filename << " for reading.\n";
        exit(1);
    }
	
	while(input.getline(temp,LINEMAX))
	{
		if(temp[0] != '\0' && temp[0] != '#') // skips blank lines and comments
        {
			switch(stage)
			{
				case 0:
					readDpt(temp);
					stage++;
					break;
				case 1:
					p1.clear();
					parseLine(temp,p1);
					stage++;
					break;
				case 2:
					if(temp[0] == '*') // there is no basecase
					{
						Polynomial ptemp(p1);
						poly.push_back(ptemp);
						stage = 1;
					}else
					{
						b1.clear(); 
						parseLine(temp,b1);
						Polynomial ptemp(p1,b1);
						poly.push_back(ptemp);
						stage++;
					}
					break;
				case 3: // catch the '*' after the base case
					stage = 1;
					break;
				default:
					cout << "Error: reading input\n";
					exit(1);
			}
		}
	}
	
	input.close();
}

void ReadConfig::parseLine(char *in,vector<int> &a)
{
	int x;
	char *sep = " \t";
	char *token,*token_ptr;
	
	for(token = (char*)strtok_r(in,sep,&token_ptr);
		token;
		token = (char*)strtok_r(NULL,sep,&token_ptr))
	{
		x = atoi(token);
		a.push_back(x);
	}
}

void ReadConfig::readDpt(const char *in)
{
	dpt = atof(in);
}

void ReadConfig::print() const
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(10);
	cout << "Digits per Terms: " << dpt << endl;
	
	cout << "The polynomials are: \n";
	for(int i = 0; i < (int)poly.size();i++)
		cout << poly[i] << endl;
}

