// $Log: poly.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
#include <vector>
using namespace std;

#include <gmpxx.h>
#include "poly.h"

Polynomial::Polynomial() :
	degree(0),has_base_case(false),done_start_CR(false),last_x_CR(0)
{
	last_list_CR = new mpz_class[10];
}

Polynomial::Polynomial(vector<int> &c) :
	has_base_case(false),done_start_CR(false),last_x_CR(0)
{
	int size = (int)c.size();
	
	for(int i = 0;i < size;i++)
		coefficents.push_back(c[i]);
	degree = size;
	last_list_CR = new mpz_class[degree];
}

Polynomial::Polynomial(vector<int> &c,vector<int> &b) :
	has_base_case(true),done_start_CR(false),last_x_CR(0)
{
	int size = (int)c.size();
	for(int i = 0;i < size;i++)
		coefficents.push_back(c[i]);
	degree = size;
	size = (int)b.size();
	for(int i = 0; i < size; i++)
		base_case.push_back(b[i]);
	last_list_CR = new mpz_class[degree];
}

Polynomial::Polynomial(vector<int> &c,int x,int y) :
	has_base_case(true),done_start_CR(false),last_x_CR(0)
{
	int size = (int)c.size();
	
	for(int i = 0;i < size;i++)
		coefficents.push_back(c[i]);
	degree = size;
	base_case.push_back(x);
	base_case.push_back(y);
	last_list_CR = new mpz_class[degree];
}

Polynomial::~Polynomial()
{
	delete [] last_list_CR;
}

Polynomial& Polynomial::operator= (const Polynomial &copy)
{
	if(this != &copy)
	{
		coefficents.clear();
		degree = copy.degree;
		has_base_case = copy.has_base_case;
		int size = (int)copy.coefficents.size();
		for(int i = 0; i < size;i++)
			coefficents.push_back(copy.coefficents[i]);
		if(has_base_case)
		{
			size = copy.base_case.size();
			for(int i=0; i < size;i++)
				base_case.push_back(copy.base_case[i]);
		}
	}
	return *this;
}

Polynomial::Polynomial(const Polynomial &copy)
{
	degree = copy.degree;
	has_base_case = copy.has_base_case;
	int size = (int)copy.coefficents.size();
	for(int i = 0; i < size;i++)
		coefficents.push_back(copy.coefficents[i]);
	if(has_base_case)
	{
		size = copy.base_case.size();
		for(int i=0; i < size;i++)
			base_case.push_back(copy.base_case[i]);
	}
	done_start_CR = false;
	last_x_CR = 0;
	last_list_CR = new mpz_class[degree];
}

void Polynomial::setCoefficents(const vector<int>& input)
{
	int size = (int)input.size();
	for(int i = 0; i < size;i++)
		coefficents.push_back(input[i]);
	degree = size;
}

int Polynomial::getDegree() const
{
	return degree;
}

void Polynomial::setBaseCase(const vector<int> &input)
{
	int size = (int)input.size();
	for(int i = 0; i < size;i++)
		base_case.push_back(input[i]);
	has_base_case = true;
}

bool Polynomial::hasBaseCase()
{
	return has_base_case;
}

void Polynomial::evaluateHorner(const long n, mpz_class &result)
{
	int size = (int)coefficents.size();

	if(has_base_case)
	{
		if(n == base_case[0])
		{
			result = base_case[1];
			return;
		}
	}
	
	result = 0;
	for(int i = 0; i < size; i++)
	{
		result *= n;
		result += coefficents[i];
	}
}

void Polynomial::evaluateHorner(const mpz_class &n, mpz_class &result)
{
	int size = (int)coefficents.size();
	
	if(has_base_case)
	{
		if(n == base_case[0])
		{
			result = base_case[1];
			return;
		}
	}
	
	result = 0;
	for(int i = 0; i < size; i++)
	{
		result *= n;
		result += coefficents[i];
	}
}

void Polynomial::evaluateCR(const long x,mpz_class &answer)
{
	// will require 3 new variables added to the class - possibly as a struct/class?
	// - lastx - hte last value the polynomial was check against
	// - lastlist - the list of values calcualted for the polynomial for CR's
	// - donestart - a boolean function to specify if the initial list has been done
	
	// evaluate the polynomial for the first time - this is the
	// base case
	// if it is not hte base case check to see if the value to 
	// be evaluated is the next number since the last evaluation
	// 1. if it is, return the next row
	// 2. it is larger than the last one, but not the next
	//		- simply loop until it reaches the correct point
	//		  *** this is somewhere that it may be decided that if 
	//			the next value to be calcuated is larger than a
	//			constant value, then evaluate the number as a base case
	// 3. the number is smaller than the last number
	//		- follow the same procedure as the above for higher values, but
	//			apply it to reduction
	if(!done_start_CR)
	{
		findFirstRowCR(x,last_list_CR);
		if((has_base_case) && (x == base_case[0]))
			done_start_CR = false;
		else
			done_start_CR = true;
	}else
	{
		if((x - last_x_CR) == 1)
		{
			last_x_CR = x;
			evalNextRowCR(last_list_CR);
		}else if(((x - last_x_CR) > 1) || ((x - last_x_CR) < 0))
		{
			findFirstRowCR(x,last_list_CR);
			last_x_CR = x;
		}
	}
	answer = last_list_CR[0];
}

void Polynomial::findFirstRowCR(const long start_point,mpz_class *first_row)
{
	mpz_class table[degree][degree]; // n * n table required to find initial row
	long temp;
	int end = degree;
	
	temp = start_point;
	for(int i = 0; i < degree; i++,temp++) // build initial row p_n
		evaluateHorner(temp,table[0][i]);
	
	// now calculate p_n-1 -> p_0
	for(int i = 1; i < degree; i++)
	{
		for(int j = 0; j < end;j++)
			table[i][j] = table[i - 1][j + 1] - table[i - 1][j];
		end--;
	}
	
	// copy results into the vector for the first row
	for(int i = 0; i < degree; i++)
		first_row[i] = table[i][0];
}

void Polynomial::evalNextRowCR(mpz_class *data)
{
	for(int i = 0; i < degree - 1; i++)
		data[i] += data[i + 1];
}

void Polynomial::printPoly()
{
	bool firstterm = true;
	
	if(degree == 0)
		cout << "0\n";
	else
	{
		for(int i = 0; i < degree; i++)
		{
			if(coefficents[i] != 0)
			{
				if(firstterm)
				{
					if(degree == 1)
						cout << coefficents[i];
					else
					{
						if(coefficents[i] == 1)
							cout << "n^" << degree - i - 1;
						else if(coefficents[i] == -1)
							cout << "-n^" << degree - i - 1;
						else
							cout << coefficents[i] << "n^" << degree - i - 1;
					}
					firstterm = false;					
				}
				else
				{
					if((degree - i - 1) == 0)
					{
						if(coefficents[i] > 0)
							cout << " + " << coefficents[i];
						else
							cout << " - " << coefficents[i] * -1;
					}
					else
					{
						if(coefficents[i] > 0)
							cout << " + " << coefficents[i] << "n^" << degree - i - 1;
						else
							cout << " - " << coefficents[i] * -1 << "n^" << degree - i - 1;
					}
				}
			}
		}
		cout << endl;
	}
}

ostream& operator <<(ostream &outs,const Polynomial &p)
{
	bool firstterm = true;
	
	if(p.degree == 0)
		cout << "0";
	else
	{
		for(int i = 0; i < p.degree; i++)
		{
			if(p.coefficents[i] != 0)
			{
				if(firstterm)
				{
					if(p.degree == 1)
						cout << p.coefficents[i];
					else
					{
						if(p.coefficents[i] == 1)
							cout << "n^" << p.degree - i - 1;
						else if(p.coefficents[i] == -1)
							cout << "-n^" << p.degree - i - 1;
						else
							cout << p.coefficents[i] << "n^" << p.degree - i - 1;
					}
					firstterm = false;
				}
				else
				{
					if((p.degree - i - 1) == 0)
					{
						if(p.coefficents[i] > 0)
							cout << " + " << p.coefficents[i];
						else
							cout << " - " << p.coefficents[i] * -1;
					}
					else
					{
						if(p.coefficents[i] > 0)
							cout << " + " << p.coefficents[i] << "n^" << p.degree - i - 1;
						else
							cout << " - " << p.coefficents[i] * -1 << "n^" << p.degree - i - 1;
					}
				}
			}
		}
	}
	return outs;
}
