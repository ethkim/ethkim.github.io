// $Log: result.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
using namespace std;

#include <gmpxx.h>
#include "result.h"
#include "pfrint.h"

Result::Result() 
{
}

Result::Result(Result &copy)
{
	T = copy.T;
	P = copy.P;
	Q = copy.Q;
}

Result::Result(mpz_class &t,mpz_class &p,mpz_class &q)
{
	T.reduce(t);
	P.reduce(p);
	Q.reduce(q);
}

Result &Result::operator= (const Result &copy)
{
	if(this != &copy)
	{
		T = copy.T;
		P = copy.P;
		Q = copy.Q;
	}
	return *this;
}

