// $Log: pfrint.h,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#ifndef PFRINT_H_
#define PFRINT_H_

#include <gmpxx.h>
#include "prime.h"

class PFRInt
{
	private:
		mpz_class x;
		int *exp;
		static int num_primes;
		static int *primes;
		static int *exp_temp;
		static int *exp_tmp2;

	public:
		PFRInt();
		PFRInt(mpz_class&);
		~PFRInt();
		void reduce(mpz_class&);
		void restore(mpz_class&);
		void restore2(mpz_class&);
		void expPFRInt(int);
		void setx(const mpz_class&);
		PFRInt& operator= (const PFRInt&);
		PFRInt& operator+= (PFRInt&);
		PFRInt& operator*= (const PFRInt&);
		friend PFRInt operator+ (PFRInt&,PFRInt&);
		friend PFRInt operator* (const PFRInt&,const PFRInt&);
		friend void expGCD(PFRInt&,PFRInt&);
		friend void expGCD(PFRInt&,PFRInt&,PFRInt&);

		static void initPrimes(int);
		static void deletePrimes();
		static int getNumPrimes();
};

#endif
