// $Log: convseries.h,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#ifndef CONVSERIES_H_
#define CONVSERIES_H_

#include <vector>
using namespace std;

#include <gmpxx.h>
#include "poly.h"
#include "result.h"
#include "pfrint.h"

class ConvSeries
{
private:
	double dpt; // Digits Per Term
	double bpd; // Bits Per Digit
	Polynomial baseA;
	Polynomial baseP;
	Polynomial baseQ;
	
	// Operation Functions not exposed to outside world
	void binsplit(Result&,long,long);
	void postSplit(const mpz_class&, mpz_class&);
	void finalDiv(Result&,const long, mpz_class&);
	
public:
	// Constructors and Destructors
	ConvSeries();
	ConvSeries(vector<Polynomial>&,double);
	ConvSeries(Polynomial&,Polynomial&,Polynomial&,double);
	~ConvSeries();
	
	// Accessor Functions
	
	// Operation Functions
	void evaluate(const long);
	void printPoly();
	void testPoly();
};

#endif

