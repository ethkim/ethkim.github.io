// $Log: result.h,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#ifndef RESULT_H_
#define RESULT_H_

#include <gmpxx.h>
#include "pfrint.h"

class Result
{
	public:
		PFRInt T;
		PFRInt P;
		PFRInt Q;
		
		Result();
		Result(Result&);
		Result(mpz_class&,mpz_class&,mpz_class&);
		Result &operator= (const Result&);
};

#endif

