// $Log: pfrint.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstring>
using namespace std;
#include <gmpxx.h>
#include "pfrint.h"

int PFRInt::num_primes = 0;
int *PFRInt::primes = NULL;
int *PFRInt::exp_temp = NULL;
int *PFRInt::exp_tmp2 = NULL;

PFRInt::PFRInt() : x(0)
{
	if(num_primes == 0)
	{
		cerr << "Error: Prime numbers not initialized\n";
		exit(1);
	}
	exp = new int[num_primes];
}

PFRInt::PFRInt(mpz_class &standard) : x(0)
{
	if(num_primes == 0)
	{
		cerr << "Error: Prime numbers not initialized\n";
		exit(1);
	}
	exp = new int[num_primes];
	reduce(standard);
}

PFRInt::~PFRInt()
{
	delete [] exp;
}

void PFRInt::reduce(mpz_class &standard)
{
	int sign = 1;
	int divisible;
	exp[0] = mpz_scan1(standard.get_mpz_t(),0);
	mpz_fdiv_q_2exp(standard.get_mpz_t(),standard.get_mpz_t(),exp[0]);
	if (standard < 0)
	{
		sign = -1;
		standard *= -1;
	}

	int i;
	for(i = 1; i < num_primes && primes[i] <= standard; i++)
	{
		exp[i] = 0;
		for(;;)
		{
			divisible = mpz_divisible_ui_p(standard.get_mpz_t(),primes[i]);
			if(!divisible) break;
			mpz_divexact_ui(standard.get_mpz_t(),standard.get_mpz_t(),primes[i]);
			exp[i]++;
		/*
		while((standard % primes[i]) == 0)
		{
			standard /= primes[i];
			exp[i]++;
		}
		*/
		}
	}
	for ( ; i < num_primes; i++) {
	  exp[i] = 0;
	}

	x = sign*standard;
}

void PFRInt::restore(mpz_class &standard) 
{
	mpz_class tmp;
	standard = x;
	unsigned long e = exp[0];
	mpz_mul_2exp(standard.get_mpz_t(),standard.get_mpz_t(),e);
	for(int i = 1; i < num_primes;i++)
	{
		if(exp[i] > 1)
		{
			mpz_ui_pow_ui(tmp.get_mpz_t(),primes[i],exp[i]);
			standard *= tmp;
		}
		else if(exp[i] == 1)
			standard *= primes[i];
	}
}

void PFRInt::restore2(mpz_class &standard) 
{
	mpz_class tmp;
	int t;
	standard = x;
	unsigned long e = exp[0] - exp_temp[0];
	mpz_mul_2exp(standard.get_mpz_t(),standard.get_mpz_t(),e);
	for(int i = 1; i < num_primes;i++)
	{
		t = exp[i] - exp_temp[i];
		if(t > 1)
		{
			mpz_ui_pow_ui(tmp.get_mpz_t(),primes[i],t);
			standard *= tmp;
		}else if(t == 1)
			standard *= primes[i];
	}
}

void PFRInt::expPFRInt(int k)
{
	for(int i = 0; i < num_primes; i++)
		exp[i] *= k;
	mpz_pow_ui(x.get_mpz_t(),x.get_mpz_t(),k);	
}

void PFRInt::setx(const mpz_class &t)
{
	x = t;
	for(int i = 0; i < num_primes; i++)
		exp[i] = 0;
}

PFRInt& PFRInt::operator= (const PFRInt &copy)
{
	if(this != &copy)
	{
		memcpy(exp,copy.exp,num_primes * sizeof(int));
		x = copy.x;
	}
	
	return *this;
}


PFRInt& PFRInt::operator+= (PFRInt &a1)
{
	mpz_class x1;

	for(int i = 0; i < num_primes; i++)
	{
		if(exp[i] <= a1.exp[i])
			exp_temp[i] = exp[i];	
		else
			exp_temp[i] = a1.exp[i];
	}

	restore2(x1);
	x = x1;
	a1.restore2(x1);
	x += x1;

	memcpy(exp,exp_temp,num_primes * sizeof(int));

	unsigned long e = mpz_scan1(x.get_mpz_t(),0);
	mpz_fdiv_q_2exp(x.get_mpz_t(),x.get_mpz_t(),e);
	exp[0] += e;

	return *this;
}

PFRInt& PFRInt::operator*= (const PFRInt &a1)
{
	for(int i = 0; i < num_primes; i++)
		exp[i] += a1.exp[i];
	x *= a1.x;

	return *this;
}

PFRInt operator+ (PFRInt &a1, PFRInt &a2)
{
	PFRInt result;
	mpz_class x1;

	for(int i = 0; i < PFRInt::num_primes; i++)
	{
		if(a1.exp[i] <= a2.exp[i])
			PFRInt::exp_temp[i] = a1.exp[i];
		else
			PFRInt::exp_temp[i] = a2.exp[i];
	}

	memcpy(result.exp,PFRInt::exp_temp,PFRInt::num_primes * sizeof(int));
	a1.restore2(x1);
	result.x = x1;
	a2.restore2(x1);
	result.x += x1;

	unsigned long e = mpz_scan1(result.x.get_mpz_t(),0);
	mpz_fdiv_q_2exp(result.x.get_mpz_t(), result.x.get_mpz_t(), e);
	result.exp[0] += e;

	return result;
}

PFRInt operator* (const PFRInt &a1,const PFRInt &a2)
{
	PFRInt result;

	for(int i = 0; i < PFRInt::num_primes; i++)
		result.exp[i] = a1.exp[i] + a2.exp[i];
	result.x = a1.x * a2.x;

	return result;
}

void expGCD(PFRInt &a1,PFRInt &a2)
{
	int temp;
	for(int i = 0; i < PFRInt::num_primes;i++)
	{
		if(a1.exp[i] <= a2.exp[i])
			temp = a1.exp[i];
		else
			temp = a2.exp[i];
		a1.exp[i] -= temp;
		a2.exp[i] -= temp;
	}
}

void expGCD(PFRInt &a1,PFRInt &a2,PFRInt &a3)
{
	int temp;
	for(int i = 0;i < PFRInt::num_primes;i++)
	{
		if(a1.exp[i] <= a2.exp[i])
			temp = a1.exp[i];
		else
			temp = a2.exp[i];
		if(a3.exp[i] < temp)
			temp = a3.exp[i];

		a1.exp[i] -= temp;
		a2.exp[i] -= temp;
		a3.exp[i] -= temp;
	}
}

void PFRInt::initPrimes(int num)
{
	primes = new int[num];
	num_primes = num;
	PrimeNumbers p(num);
	p.exportPrimes(primes);
	exp_temp = new int[num];
	exp_tmp2 = new int[num];
}

void PFRInt::deletePrimes()
{
	delete [] primes;
	delete [] exp_temp;
	delete [] exp_tmp2;
}

int PFRInt::getNumPrimes()
{
	return num_primes;
}
