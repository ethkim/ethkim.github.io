// $Log: convseries.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
#include <fstream>
#include <vector>
#include <cassert>
using namespace std;

#include <gmpxx.h>
#include <unistd.h>
#include <sys/resource.h>

#include "result.h"
#include "poly.h"
#include "convseries.h"
#include "pfrint.h"
#include "util.h"

ConvSeries::ConvSeries() : 
	dpt(0), bpd(3.32192809488736234787)
{
}

ConvSeries::ConvSeries(vector<Polynomial> &p,double d) :
	bpd(3.32192809488736234787)
{
	dpt = d;	
	baseA = p[0];
	// this constructor assumes either 3 or 4 polynomials have been passsed in
	baseP = p[1];
	baseQ = p[2];
}

ConvSeries::ConvSeries(Polynomial &a,Polynomial &p,Polynomial &q,double d) :
	bpd(3.32192809488736234787)
{
	dpt = d;
	baseA = a;
	baseP = p;
	baseQ = q;
}

ConvSeries::~ConvSeries()
{
}

void ConvSeries::evaluate(const long precision)
{
	long terms;
	mpz_class S,answer,tmp;
	Result rt;
	ofstream file_out;
	struct rusage time[4];
	
	file_out.open("zeta-result");
	if(file_out.fail())
	{
		cout << "Unable to open file result\n";
		exit(1);
	}
	
	terms = (long)(precision/dpt) + 1;
	
	cout << "=====================================\n";
	cout << "Time profile for:\n";
	cout << "digits:" << precision << endl;
	cout << "terms:" << terms << endl;
	cout << "result:\n";
	
	// set decimal precision for displaying time results
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	
	getrusage(RUSAGE_SELF,time + 3);

	binsplit(rt,0,terms);
	getrusage(RUSAGE_SELF, time + 0);
	cout << "binsplit Time: " << get_elapsed(time[3], time[0]) << endl;
	
	finalDiv(rt,precision,S);
	getrusage(RUSAGE_SELF, time + 1);
	cout << "finaldiv Time: " << get_elapsed(time[0], time[1]) << endl;
	
	postSplit(S,answer);
	getrusage(RUSAGE_SELF, time + 2);
	cout << "postsplit Time: " << get_elapsed(time[1], time[2]) << endl;
	cout << "Total Time: " << get_elapsed(time[3], time[2]) << endl;
	file_out << answer << endl;

	file_out.close();
}

void ConvSeries::binsplit(Result &r,long n1,long n2)
{
	Result t;
	mpz_class tmp;
	int i, diff;
	
	diff = n2 - n1;
	assert(diff != 0);
	if(diff <= 5)
	{
		for(i=0;i<diff;i++) 
		{
			//baseP.evaluateHorner(n1 + i,tmp);
			if((n1 + i) == 0)
				tmp = 1;
			else
				tmp = -1 * (n1 + i);
			t.P.reduce(tmp);
			t.P.expPFRInt(5);
           	baseQ.evaluateCR(n1 + i,tmp);
			t.Q.reduce(tmp);
			t.Q.expPFRInt(5);
			baseA.evaluateCR(n1 + i, tmp);
			t.T.setx(tmp);
			t.T *= t.P;

			if(i==0) 
			{
				r = t;
			}else
			{
				r.Q *= t.Q;
				r.T *= t.Q;
				t.T *= r.P;
				r.P *= t.P;
				r.T += t.T;
			//	expGCD(r.P,r.Q,r.T);
			}
		}		
	}else
	{
		int nm=(n1+n2)/2;
		binsplit(r, n1, nm);
		binsplit(t, nm, n2);
		
		r.Q *= t.Q;
		r.T *= t.Q;
		t.T *= r.P;
		r.P *= t.P;
		r.T += t.T;
	}
}

void ConvSeries::postSplit(const mpz_class &S, mpz_class &answer)
{
	// this is specific to calculating Zeta(3) - this is the constant
	answer = S/2;
}

void ConvSeries::finalDiv(Result &rt,const long prec, mpz_class &S)
{
	mpz_class BQ, T;
    mpz_class B, Q;
    
	expGCD(rt.Q,rt.T);

	rt.Q.restore(BQ);
	rt.T.restore(T);

	cout << "Number of digits:\n";
	cout << "\tT: " << mpz_sizeinbase(T.get_mpz_t(),10) << endl;
	cout << "\tQ: " << mpz_sizeinbase(BQ.get_mpz_t(),10) << endl;
	
    B = 10;
    mpz_pow_ui(Q.get_mpz_t(), B.get_mpz_t(), prec); //Q holds 10^digits
    mpz_mul(T.get_mpz_t(), T.get_mpz_t(), Q.get_mpz_t()); //T holds T*(10^digits)
    mpz_fdiv_q(S.get_mpz_t(), T.get_mpz_t(), BQ.get_mpz_t());	
}


void ConvSeries::printPoly()
{
	cout << "***********************************************************************\n";
	cout << "The polynomials are:\n";
	cout << baseA << endl << baseP << endl << baseQ << endl;
	cout << "***********************************************************************\n";
}

void ConvSeries::testPoly()
{
	mpz_class temp[4];
	mpz_class num = 0;
	int num2 = 0;
	
	for(int x = 0 ; x < 1000000;x++){
	baseA.evaluateHorner(num,temp[0]);
	
	baseP.evaluateHorner(num,temp[2]);
	
	baseQ.evaluateHorner(num,temp[3]);
	
	num++;
	}
	cout << "Poly A: " << temp[0] << endl;
	cout << "Poly P: " << temp[2] << endl;
	cout << "Poly Q: " << temp[3] << endl << endl;
	cout << endl;
	for(int x = 0 ;x<1000000; x++){
	baseA.evaluateCR(num2,temp[0]);
	
	baseP.evaluateCR(num2,temp[2]);
	
	baseQ.evaluateCR(num2,temp[3]);
	
	num2++;
	}
	cout << "Poly A: " << temp[0] << endl;
	cout << "Poly P: " << temp[2] << endl;
	cout << "Poly Q: " << temp[3] << endl<<endl;
}

