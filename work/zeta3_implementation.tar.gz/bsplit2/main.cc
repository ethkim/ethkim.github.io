// $Log: main.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;
#include <sys/resource.h>

#include "poly.h"
#include "convseries.h"
#include "readconf.h"
#include "prime.h"
#include "pfrint.h"

int inc_stacksize(void)
{
	struct rlimit limit;
	int ret;
	
	if(getrlimit(RLIMIT_STACK, &limit) < 0)
	{
		cout << "getrlimit error\n";
		return -1;
	}
	limit.rlim_cur = RLIM_INFINITY;
	limit.rlim_max = RLIM_INFINITY; 
	ret = setrlimit(RLIMIT_STACK, &limit);
	cout << "setrlimit = " << ret << endl;
	return 0;
}

int main (int argc, char *argv[]) 
{
    vector<Polynomial> x;
	ReadConfig test2;
	int digits,prms;
	
	inc_stacksize();

	if(argc != 3)
	{
		cout << "Please enter the number primes and digits\n";
		exit(1);
	}

	prms = atoi(argv[1]);
	PFRInt::initPrimes(prms);

	test2.readFile("input.dat");
	
	test2.getPoly(x);
	ConvSeries trial(x,3.0102348);
	
	digits = atoi(argv[2]);
	trial.evaluate(digits);

	PFRInt::deletePrimes();
	return 0;
}

