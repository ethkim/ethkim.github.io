#!/bin/sh

for tests in 50 100 150 200 250 300 350 400 450 500 550 600 650 700
#for tests in 1000 2000 3000 4000
do
	echo "******** $tests Primes *********" >> times-new
	./zeta $tests 1000000 >> times-new
done
