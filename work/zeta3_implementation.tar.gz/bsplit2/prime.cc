// $Log: prime.cpp,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#include <iostream>
#include <vector>
#include <fstream>
#include <cstdlib>
using namespace std;
#include "prime.h"

PrimeNumbers::PrimeNumbers()
{
	num_primes = 100;
	primes.push_back(2);
	generate(100);
}

PrimeNumbers::PrimeNumbers(int num)
{
	primes.push_back(2);
	if( num <= MAXN)
	{
		num_primes = num;
		generate(num);
	}
	else
		cout << "Input size error: greater than " << MAXN << endl;
}

PrimeNumbers::PrimeNumbers(char *filename)
{
	// read a file of primes in to the object's vector
	ifstream input;
	int tmp,count = 0;

	input.open(filename);
	if(input.fail())
	{
		cout << "Unable to open file: " << filename << endl;
		exit(1);
	}
	while(input >> tmp)
	{
		primes.push_back(tmp);
		count++;
	}
	num_primes = count;
	input.close();
}

PrimeNumbers::~PrimeNumbers()
{
}

void PrimeNumbers::generate(int num)
{
	int count = 1;
	int last = 3,i;
	bool p;

	while(count < num)
	{
		p = false;
		for(i = last; !p; i += 2){
			if(isPrime(i)){
				primes.push_back(i);
				p = true;
			}
		}
		count++;
		last = i;
	}
}

void PrimeNumbers::print()
{
	cout << "The primes to " << num_primes << " are:\n";
	for(int i = 0; i < num_primes;i++)
		cout << i + 1 << ": " << primes[i] << endl;
}

bool PrimeNumbers::isPrime(int num)
{
	if(num == 2) return true;
	if(num == 3) return true;
	if((num % 2) == 0) return false;
	if((num % 3) == 0) return false;
	int count = (int)primes.size();
	for(int x = 2; x < count; x++) {
		if((num % primes[x]) == 0)
			return false;
	}
	return true;
}

bool PrimeNumbers::checkPrime(int num)
{
	if(num > primes[num_primes - 1])
	{
		cout << "Number is larger than calculated primes\n";
		return false;
	}
	for(int i = 0; i < num_primes; i++){
		if(num == primes[i]) return true;
	}
	return false;
}

void PrimeNumbers::writeFile(char *filename)
{
	ofstream output;

	output.open(filename);
	if(output.fail())
	{
		cout << "Error opening: " << filename << endl;
		exit(1);
	}

	for(int i = 0; i < num_primes; i++)
		output << primes[i] << endl;

	output.close();
}

void PrimeNumbers::exportPrimes(int *out) const
{
	int size = primes.size();
	for(int i = 0; i < size;i++)
		out[i] = primes[i];
}
