// $Log: prime.h,v $
// Revision 1.2  2004/08/03 16:49:18  bgergel
// added script line to insert commit comments to the top of each file code
//

#ifndef PRIME_H_
#define PRIME_H_

#include <vector>
using namespace std;
/**
 * PrimeNumbers Class
 * Barry Gergel
 * July 2004
 * --
 *  This is a basic prime number class that is designed to
 *  generate the first x primes based on the user's input. 
 *  It is designed to pretty much only work on integers - the 
 *  small primes.
 *
 *  Running Time to generate primes: O(n^3)
 */
class PrimeNumbers{
	private:
		vector<long long> primes;
		int num_primes;
		static const int MAXN = 2147483647;

	public:
		// Constructors and Destructor
		PrimeNumbers();
		PrimeNumbers(int);
		PrimeNumbers(char*);
		~PrimeNumbers();
		
		// Accessor Members

		// Functionality Members
		void generate(int);
		void print();
		bool isPrime(int);
		bool checkPrime(int);
		void writeFile(char*);
		void exportPrimes(int*) const;
};

#endif
