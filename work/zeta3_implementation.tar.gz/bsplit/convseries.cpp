// $Log: convseries.cpp,v $
// Revision 1.2  2004/08/03 17:02:40  bgergel
// log tag added to each file
//

#include <iostream>
#include <fstream>
#include <vector>
#include <cassert>
#include <cstdio>
using namespace std;

#include <gmpxx.h>
#include <time.h>
#include <sys/time.h>

#include "poly.h"
#include "convseries.h"

ConvSeries::ConvSeries() : 
	hasB(false), dpt(0), bpd(3.32192809488736234787)
{
}

ConvSeries::ConvSeries(vector<Polynomial> &p,double d) :
	bpd(3.32192809488736234787)
{
	dpt = d;	
	baseA = p[0];
	// this constructor assumes either 3 or 4 polynomials have been passsed in
	int size = (int)p.size();
	if(size == 3)
	{
		hasB = false;		
		baseP = p[1];
		baseQ = p[2];
	}
	else
	{
		hasB = true;
		baseB = p[1];
		baseP = p[2];
		baseQ = p[3];
	}
}

ConvSeries::ConvSeries(Polynomial &a,Polynomial &p,Polynomial &q,double d) :
	hasB(false),bpd(3.32192809488736234787)
{
	dpt = d;
	baseA = a;
	baseP = p;
	baseQ = q;
}

ConvSeries::ConvSeries(Polynomial &a,Polynomial &b,Polynomial &p,Polynomial &q,double d) :
	hasB(true),bpd(3.32192809488736234787)
{
	dpt = d;
	baseA = a;
	baseB = b;
	baseP = p;
	baseQ = q;
}

ConvSeries::~ConvSeries()
{
}

void ConvSeries::evaluate(const long precision)
{
	long terms;
	mpz_class S,answer,gcd;
	clock_t begin, end;
	double total_time = 0,r_time = 0;
	Result rt;
	ofstream file_out;
	
	file_out.open("result");
	if(file_out.fail())
	{
		cout << "Unable to open file result\n";
		exit(1);
	}
	
	terms = (long)(precision/dpt) + 1;
	
	cout << "=====================================\n";
	cout << "Time profile for:\n";
	cout << "digits:" << precision << endl;
	cout << "terms:" << terms << endl;
	cout << "result:\n";
	
	// set decimal precision for displaying time results
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	
	begin = clock();
	if(hasB)
		split_withB(rt,0,terms);
	else
		split_withoutB(rt,0,terms);
	//GCD OPERATION GODES HERE
    
	//if((file_tq = fopen("tq-binsplit","w")) == NULL)
	//{
	//	cout << "Unable to open the file tq-binsplit\n";
	//	exit(1);
	//}
	//mpz_out_rw(file_tq,rt.T.get_mpz_t());
	//mpz_out_raw(file_tq,rt.Q.get_mpz_t()); 

	//fclose(file_tq);

	//mpz_gcd(gcd.get_mpz_t(), rt.T.get_mpz_t(), rt.Q.get_mpz_t());
	//rt.Q /= gcd;
	//rt.T /= gcd;
	end = clock();
	r_time = (double)(end - begin) / CLOCKS_PER_SEC;
	total_time += r_time;

	cout << "Binsplit:" << r_time << endl;
	
	begin = clock();
	if(hasB)
		finalDiv_withB(rt,precision,S);
	else
		finalDiv_withoutB(rt,precision,S);
	end = clock();
	r_time = (double)(end - begin) / CLOCKS_PER_SEC;
	total_time += r_time;
	cout << "final_div: " << r_time << endl;
	
	begin = clock();
	postSplit(S,answer);
	end=clock();
	r_time = (double)(end - begin) / CLOCKS_PER_SEC;
	total_time += r_time;
	cout << "post_binsplit: " << r_time << endl;
	cout << "Total Time: " << total_time << endl;
	file_out << answer << endl;

	file_out.close();
}

void ConvSeries::split_withoutB(Result &r,long n1,long n2)
{
	Result t;
	mpz_class gcd;
	int i, diff;
	
	diff = n2 - n1;
	assert(diff != 0);
	if(diff <= 5)
	{
		for(i=0;i<diff;i++) 
		{
			baseP.evaluateCR(n1 + i, t.P);
            baseQ.evaluateCR(n1 + i,t.Q);
			baseA.evaluateCR(n1 + i, t.T);
			t.T *= t.P;
			//now merge
			if(i==0) 
			{
				r = t;
			}else
			{
				r.Q *= t.Q;
				r.T *= t.Q;
				t.T *= r.P;
				r.P *= t.P;
				r.T += t.T;
				//GCD OPERATION GODES HERE
				mpz_gcd(gcd.get_mpz_t(), r.P.get_mpz_t(), r.Q.get_mpz_t());
				mpz_gcd(gcd.get_mpz_t(), gcd.get_mpz_t(), r.T.get_mpz_t());
				r.P /= gcd;
				r.Q /= gcd;
				r.T /= gcd;
			}
		}		
	}else
	{
		int nm=(n1+n2)/2;
		split_withoutB(r, n1, nm);
		split_withoutB(t, nm, n2);
		
		r.Q *= t.Q;
		r.T *= t.Q;
		t.T *= r.P;
		r.P *= t.P;
		r.T += t.T;
	}
}

void ConvSeries::split_withB(Result &r,long n1,long n2)
{
	Result t;
	mpz_class gcd;
	int i, diff;
	
	diff = n2 - n1;
	assert(diff != 0);
	if(diff <= 5)
	{
		for(i=0;i<diff;i++) 
		{
			baseP.evaluateCR(n1 + i, t.P); 
            baseQ.evaluateCR(n1 + i, t.Q);
			baseB.evaluateCR(n1 + i, t.B);
			baseA.evaluateCR(n1 + i, t.T);
			t.T *= t.P;
			//now merge
			if(i==0) {
				r = t;
			}else
			{
				r.Q *= t.Q;
				r.T *= t.B;
				r.T *= t.Q;
				t.T *= r.P;
				t.T *= r.B;
				r.B *= t.B;
				r.P *= t.P;
				r.T += t.T;
				
				//GCD OPERATION GODES HERE
				mpz_gcd(gcd.get_mpz_t(), r.P.get_mpz_t(), r.Q.get_mpz_t());
				mpz_gcd(gcd.get_mpz_t(),gcd.get_mpz_t(),r.T.get_mpz_t());
				mpz_gcd(gcd.get_mpz_t(), gcd.get_mpz_t(), r.B.get_mpz_t());
				
				r.P /= gcd;
				r.Q /= gcd;
				r.B /= gcd;
				r.T /= gcd;
			}
		}		
	}else
	{
		int nm=(n1+n2)/2;
		split_withB(r, n1, nm);
		split_withB(t, nm, n2);
		
		r.Q *= t.Q;
		r.T *= t.B;
		r.T *= t.Q;
		t.T *= r.P;
		t.T *= r.B;
		r.B *= t.B;
		r.P *= t.P;
		r.T += t.T;
	}
}

void ConvSeries::postSplit(const mpz_class &S, mpz_class &answer)
{
	// this is specific to calculating Zeta(3) - this is the constant
	answer = S/2;
}

void ConvSeries::finalDiv_withoutB(Result &rt,const long prec, mpz_class &S)
{
	mpz_class BQ, T;
    mpz_class B, Q;
    
	cout << "Number of digits:\n";
	cout << "\tT: " << mpz_sizeinbase(rt.T.get_mpz_t(),10) << endl;
 	cout << "\tQ: " << mpz_sizeinbase(rt.Q.get_mpz_t(),10) << endl;
	
	BQ = rt.Q;
	
    T = rt.T; 
    B = 10;
    mpz_pow_ui(Q.get_mpz_t(), B.get_mpz_t(), prec); //Q holds 10^digits
    mpz_mul(T.get_mpz_t(), T.get_mpz_t(), Q.get_mpz_t()); //T holds T*(10^digits)
    mpz_fdiv_q(S.get_mpz_t(), T.get_mpz_t(), BQ.get_mpz_t());	
}

void ConvSeries::finalDiv_withB(Result &rt,const long prec, mpz_class &S)
{
	mpz_class BQ, T;
    mpz_class B, Q;
    
	if(hasB)
	{
		B = rt.B;
		Q = rt.Q;  
		mpz_mul(BQ.get_mpz_t(), B.get_mpz_t(), Q.get_mpz_t());
	}
	else
	BQ = rt.Q;
	
    T = rt.T; 
    B = 10;
    mpz_pow_ui(Q.get_mpz_t(), B.get_mpz_t(), prec); //Q holds 10^digits
    mpz_mul(T.get_mpz_t(), T.get_mpz_t(), Q.get_mpz_t()); //T holds T*(10^digits)
    mpz_fdiv_q(S.get_mpz_t(), T.get_mpz_t(), BQ.get_mpz_t());	
}


void ConvSeries::printPoly()
{
	cout << "***********************************************************************\n";
	cout << "The polynomials are:\n";
	cout << baseA << endl << baseB << endl << baseP << endl << baseQ << endl;
	cout << "***********************************************************************\n";
}

void ConvSeries::testPoly()
{
	mpz_class temp[4];
	mpz_class num = 0;
	int num2 = 0;
	
	for(int x = 0 ; x < 1000000;x++){
	baseA.evaluateHorner(num,temp[0]);
	
	baseB.evaluateHorner(num,temp[1]);
	
	baseP.evaluateHorner(num,temp[2]);
	
	baseQ.evaluateHorner(num,temp[3]);
	
	num++;
	}
	cout << "Poly A: " << temp[0] << endl;
	cout << "Poly B: " << temp[1] << endl;
	cout << "Poly P: " << temp[2] << endl;
	cout << "Poly Q: " << temp[3] << endl << endl;
	cout << endl;
	for(int x = 0 ;x<1000000; x++){
	baseA.evaluateCR(num2,temp[0]);
	
	baseB.evaluateCR(num2,temp[1]);
	
	baseP.evaluateCR(num2,temp[2]);
	
	baseQ.evaluateCR(num2,temp[3]);
	
	num2++;
	}
	cout << "Poly A: " << temp[0] << endl;
	cout << "Poly B: " << temp[1] << endl;
	cout << "Poly P: " << temp[2] << endl;
	cout << "Poly Q: " << temp[3] << endl<<endl;
}

Result::Result() : B(0),T(0),P(0),Q(0)
{
}

Result::Result(Result &copy)
{
	B = copy.B;
	T = copy.T;
	P = copy.P;
	Q = copy.Q;
}

Result::Result(mpz_class &b,mpz_class &t,mpz_class &p,mpz_class &q)
{
	B = b;
	T = t;
	P = p;
	Q = q;
}

Result &Result::operator= (const Result &copy)
{
	if(this != &copy)
	{
		B = copy.B;
		T = copy.T;
		P = copy.P;
		Q = copy.Q;
	}
	return *this;
}

