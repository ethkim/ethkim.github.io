// $Log: readconf.h,v $
// Revision 1.2  2004/08/03 17:02:40  bgergel
// log tag added to each file
//

#ifndef READCONF_H_
#define READCONF_H_

#include "poly.h"

class ReadConfig{
private:
	double dpt;
	vector<Polynomial> poly;
	
public:
	// Constructors and Destructors
	ReadConfig();
	~ReadConfig();
	
	// Accessor Functions
	double getDpt();
	void getPoly(vector<Polynomial>&) const;
	
	// Operation Functions
	void readFile(const char *filename);
	void parseLine(char*,vector<int>&);
	void readDpt(const char*);
	void print() const;
};

#endif

