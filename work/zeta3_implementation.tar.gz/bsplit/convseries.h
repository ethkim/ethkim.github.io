// $Log: convseries.h,v $
// Revision 1.2  2004/08/03 17:02:40  bgergel
// log tag added to each file
//

#ifndef CONVSERIES_H_
#define CONVSERIES_H_

#include <vector>
using namespace std;

#include <gmpxx.h>
#include "poly.h"

enum DisplayResults {SCREENOUT,FILEOUT,BOTH};

class Result
{
public:
	mpz_class B;
	mpz_class T;
	mpz_class P;
	mpz_class Q;
	
	Result();
	Result(Result&);
	Result(mpz_class&,mpz_class&,mpz_class&,mpz_class&);
	Result &operator= (const Result&);
};

class ConvSeries
{
private:
	bool hasB; // True if B > 1
	double dpt; // Digits Per Term
	double bpd; // Bits Per Digit
	Polynomial baseA;
	Polynomial baseB;
	Polynomial baseP;
	Polynomial baseQ;
	
	// Operation Functions not exposed to outside world
	void split_withoutB(Result&,long,long);
	void split_withB(Result&,long,long);
	void postSplit(const mpz_class&, mpz_class&);
	void finalDiv_withoutB(Result&,const long, mpz_class&);
	void finalDiv_withB(Result&,const long, mpz_class&);
	
public:
	// Constructors and Destructors
	ConvSeries();
	ConvSeries(vector<Polynomial>&,double);
	ConvSeries(Polynomial&,Polynomial&,Polynomial&,double);
	ConvSeries(Polynomial&,Polynomial&,Polynomial&,Polynomial&,double);
	~ConvSeries();
	
	// Accessor Functions
	
	// Operation Functions
	void evaluate(const long);
	void printPoly();
	void testPoly();
};

#endif

