// $Log: poly.h,v $
// Revision 1.2  2004/08/03 17:02:40  bgergel
// log tag added to each file
//

#ifndef POLY_H_
#define POLY_H_

#include <vector>
using namespace std;
#include <gmpxx.h>

class Polynomial
{
	private:
		int degree;
		vector<int> coefficents;
		bool has_base_case;
		vector<int> base_case;
		bool done_start_CR;
		mpz_class last_x_CR; 
		mpz_class *last_list_CR;
		
	public:
		// Constructors & Destructors
		Polynomial();
		Polynomial(vector<int>&);
		Polynomial(vector<int>&,vector<int>&);
		Polynomial(vector<int>&,int,int);
		~Polynomial();
	
		// Copy Functions
		Polynomial& operator= (const Polynomial&);
		Polynomial(const Polynomial&); // copy constructor
		
		// Accessor Functions
		void setCoefficents(const vector<int>&);
		int getDegree() const;
		void setBaseCase(const vector<int>&);
		bool hasBaseCase();
		
		// Operation Functions
		void evaluateHorner(const long, mpz_class&);
		void evaluateHorner(const mpz_class&,mpz_class&);
		void evaluateCR(const long,mpz_class&);
		void findFirstRowCR(const long,mpz_class*);
		void evalNextRowCR(mpz_class*);
		
		void printPoly();
		
		// Friend Functions
		friend ostream& operator <<(ostream&,const Polynomial&);
};

#endif

