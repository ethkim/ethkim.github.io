// $Log: main.cpp,v $
// Revision 1.2  2004/08/03 17:02:40  bgergel
// log tag added to each file
//

#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;
#include <sys/resource.h>

#include "poly.h"
#include "convseries.h"
#include "readconf.h"

int inc_stacksize(void)
{
	struct rlimit limit;
	int ret;
	
	if(getrlimit(RLIMIT_STACK, &limit) < 0)
	{
		cout << "getrlimit error\n";
		return -1;
	}
	limit.rlim_cur = RLIM_INFINITY;
	limit.rlim_max = RLIM_INFINITY; 
	ret = setrlimit(RLIMIT_STACK, &limit);
	cout << "setrlimit = " << ret << endl;
	return 0;
}

int main (int argc, char *argv[]) 
{
    vector<Polynomial> x;
	ReadConfig test2;
	int digits;
	int out_format;
	
	inc_stacksize();

	if(argc != 2)
	{
		cout << "Please enter the number of digits desired\n";
		exit(1);
	}

	test2.readFile("input.dat");
	
	test2.getPoly(x);
	ConvSeries trial(x,3.0102348);
	
	digits = atoi(argv[1]);
	trial.evaluate(digits);

	return 0;
}

