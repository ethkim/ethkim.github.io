#include <stdio.h>

int main(int argc, char *argv[]) {
  FILE *fp1, *fp2;
  int c;
  fp1=fopen(argv[1], "r");
  strcat(argv[1], ".converted");
  fp2=fopen(argv[1], "w");
  while((c=fgetc(fp1))!=EOF) {
    if(c!='\n' && c!='\0' && c!='\\') {
      fputc(c, fp2);
    }
  }
  
}
