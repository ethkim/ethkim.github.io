#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
#include <gmpxx.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>


#define A 13591409
#define Bb 545140134
#define C 640320
//PI
#define BITS_PER_DIGIT   3.32192809488736234787
#define DIGITS_PER_TERM 3.0102348

int gcd_level=0;


struct abpq_series_result{
  mpz_class P,Q,B,T;
};


void basea(mpz_class n, mpz_class &res) {
  if(n==0)
    res=77;
  else {
    mpz_pow_ui(res.get_mpz_t(), n.get_mpz_t(), 2);
    res=res*205+250*n+77;
  }
}

void baseb(mpf_class n, mpz_class &res) {
  res=1;
}

void basep(mpz_class n, mpz_class &res) {
  if(n==0) 
    res=1;
  else {
    mpz_pow_ui(res.get_mpz_t(), n.get_mpz_t(), 5);
    res=-1*res;
  }
}

void baseq(mpz_class n, mpz_class &res) {
  res=2*n+1;
  mpz_pow_ui(res.get_mpz_t(), res.get_mpz_t(), 5);
  res=32*res;
}



void binsplit(struct abpq_series_result &r, int n1, int n2, int depth)
{
  struct abpq_series_result One, Two, Three, Four;
  struct abpq_series_result t;
  mpz_class gcd;
  switch(n2-n1) {
  case 0:
    printf("sum_abpq: n2-n1 should be >0.\n");
    break;
  case 1: //collect the result
    basep(n1, r.P);
    baseq(n1,r.Q);
    baseb(n1,r.B);
    basea(n1, r.T);
    r.T=r.T * r.P;
    break;
//   case 2: //collect from 2 leaves
//     basep(n1, One.P);
//     baseq(n1, One.Q);
//     baseb(n1, One.B);
//     basea(n1, One.T);
//     One.T=One.T * One.P;
//     basep(n1+1, Two.P);
//     baseq(n1+1, Two.Q);
//     baseb(n1+1, Two.B);
//     basea(n1+1, Two.T);
//     Two.T=Two.T * Two.P;
//     //now merge
//     r.P=One.P * Two.P;
//     r.Q=One.Q * Two.Q;
//     r.B=One.B * Two.B;

//     r.T=Two.B * Two.Q * One.T + One.B * One.P * Two.T;
//     break;

//   case 4: // collect from 4 leaves
  
//     basep(n1, One.P);
//     baseq(n1, One.Q);
//     baseb(n1, One.B);
//     basea(n1, One.T);
//     One.T=One.T * One.P;
//     basep(n1+1, Two.P);
//     baseq(n1+1, Two.Q);
//     baseb(n1+1, Two.B);
//     basea(n1+1, Two.T);
//     Two.T=Two.T * Two.P;
//     basep(n2-1, Three.P);
//     baseq(n2-1, Three.Q);
//     baseb(n2-1, Three.B);
//     basea(n2-1, Three.T);
//     Three.T=Three.T*Three.P;
//     basep(n2, Four.P);
//     baseq(n2, Four.Q);
//     baseb(n2, Four.B);
//     basea(n2, Four.T);
//     Four.T=Four.T*Four.P;
//     //now merge
//     r.P=One.P*Two.P;
//     r.Q=One.Q*Two.Q;
//     r.B=One.B*Two.B;
//     r.T=Two.B*Two.Q*One.T+One.B*One.P*Two.T;

//     t.P=Three.P*Four.P;
//     t.Q=Three.Q*Four.Q;
//     t.B=Three.B*Four.B;
//     t.T=Four.B*Four.Q*Three.T+Three.B*Three.P*Four.T;
    
//     r.T=t.B*t.Q*r.T+r.B*r.P*t.T;
    
//     break;
  default:
    int nm=(n1+n2)/2;
    binsplit(One, n1, nm, depth+1);
    binsplit(Two, nm, n2, depth+1);

    r.P=One.P * Two.P;
    r.Q=One.Q * Two.Q;
    r.B=One.B * Two.B;

    if((n2-n1)<=5) {
      mpz_gcd(gcd.get_mpz_t(), r.P.get_mpz_t(), r.Q.get_mpz_t());
      mpz_gcd(gcd.get_mpz_t(), gcd.get_mpz_t(), r.B.get_mpz_t());
      r.P=r.P/gcd;
      r.Q=r.Q/gcd;
      r.B=r.B/gcd;
    }
    r.T=Two.B * Two.Q * One.T + One.B * One.P * Two.T;
    break;
  }
}

void post_binsplit(mpz_class S, unsigned long prec, mpz_class &pi) {
  pi=S/2;
}

void final_div(struct abpq_series_result r, unsigned long digits, mpz_class &S) {
  mpz_class BQ, T;

  mpz_class B, Q;
  B=r.B;
  Q=r.Q;
  mpz_mul(BQ.get_mpz_t(), B.get_mpz_t(), Q.get_mpz_t());

  T=r.T;
  B=10;
  mpz_pow_ui(Q.get_mpz_t(), B.get_mpz_t(), digits); //Q holds 10^digits
  mpz_mul(T.get_mpz_t(), T.get_mpz_t(), Q.get_mpz_t()); //T holds T*(10^digits)
  mpz_fdiv_q(S.get_mpz_t(), T.get_mpz_t(), BQ.get_mpz_t());


}



int inc_stacksize(void) {
  struct rlimit limit;
  int ret;
  if(getrlimit(RLIMIT_STACK, &limit)<0) {
    printf("getrlimit error\n");
    return -1;
  }
  limit.rlim_cur=RLIM_INFINITY;
  limit.rlim_max=RLIM_INFINITY;
  ret=setrlimit(RLIMIT_STACK, &limit);
  printf("setrlimit=%d\n", ret);
  return 0;
}

int main(int argc, char *argv[]) {
  if(argc!=2) {
    printf("Please enter the number of digits desired.\n");
    exit(1);
  }
  printf("=====================================\n");
  inc_stacksize();
  int digits, terms;
  digits=atoi(argv[1]);
  terms=(int)(ceil(digits/DIGITS_PER_TERM));
  mpz_class S,pi;

  struct abpq_series_result r;

  clock_t begin, end, t1, t2;
  t1=clock();

  printf("Time profile for: %d digits, %d terms\n", digits, terms);


  begin=clock();
  binsplit(r, 0, terms,0);
  end=clock();
  printf("binsplit:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);
  
  //reporting number of digits of T,B,Q
  printf("Number of digits:\n");
  printf("\tT:%d\n\tB:%d\n\tQ:%d\n", mpz_sizeinbase(r.T.get_mpz_t(), 10),\
	 mpz_sizeinbase(r.B.get_mpz_t(), 10), mpz_sizeinbase(r.Q.get_mpz_t(), 10));

  begin=clock();
  final_div(r,digits, S); 
  end=clock();
  printf("final_div:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);


  begin=clock();
  post_binsplit(S, (int)(ceil(BITS_PER_DIGIT*digits)), pi);
  end=clock();
  printf("post_binsplit:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);
  
  begin=clock();
  FILE *fp;
  strcat(argv[1], ".zeta");
  fp=fopen(argv[1], "w");
  
  //  mpf_out_str(stdout, 10, digits, pi.get_mpf_t());
  mpz_out_str(fp, 10, pi.get_mpz_t());
  fprintf(fp, "\n");
  end=clock();
  printf("mpf_out_str:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);
  fclose(fp);
  t2=clock();
  
  printf("Total Time: %.2f secs\n", (double)(t2-t1)/CLOCKS_PER_SEC);
  printf("=====================================\n");

  return 0;
}










