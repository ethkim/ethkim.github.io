void binsplit(struct abpq_series_result &r, int n1, int n2, int depth)
{
  struct abpq_series_result One, Two, Three, Four;
  struct abpq_series_result t;
  mpz_class gcd;
  switch(n2-n1) {
  case 0:
    printf("sum_abpq: n2-n1 should be >0.\n");
    break;
  case 1:  case 2: case 3: case 4: //collect the result
    cout<<"n2-n1 is:"<<n2-n1<<endl;
    for(i=0;i<(n2-n1);i++) {
      basep(n1, t.P);
      baseq(n1,t.Q);
      baseb(n1,t.B);
      basea(n1, t.T);
      t.T=t.T * t.P;
      //now merge
      if((n2-n1)==1) {
	r=t;
      }else{
	//merge
	r.P=r.P*t.P;
	r.Q=r.Q*t.Q;
	r.B=r.B*t.B;
	mpz_gcd(gcd.get_mpz_t(), r.P.get_mpz_t(), r.Q.get_mpz_t());
	mpz_gcd(gcd.get_mpz_t(), gcd.get_mpz_t(), r.B.get_mpz_t());
	r.P=r.P/gcd;
	r.Q=r.Q/gcd;
	r.B=r.B/gcd;
	
	r.T=t.B*t.Q*r.T + r.B*r.P*t.T;
      }
    }
    break;
  default:
    int nm=(n1+n2)/2;
    binsplit(One, n1, nm, depth+1);
    binsplit(Two, nm, n2, depth+1);

    r.P=One.P * Two.P;
    r.Q=One.Q * Two.Q;
    r.B=One.B * Two.B;
    r.T=Two.B * Two.Q * One.T + One.B * One.P * Two.T;
    break;
  }
}
