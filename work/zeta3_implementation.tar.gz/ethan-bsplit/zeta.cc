#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
#include <gmpxx.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>


#define A 13591409
#define Bb 545140134
#define C 640320
//PI
#define BITS_PER_DIGIT   3.32192809488736234787
#define DIGITS_PER_TERM 3.0102348



struct abpq_series_result{
  mpz_class P,Q,B,T;
};


void basea(mpz_class n, mpz_class &res) {
  if(n==0)
    res=77;
  else {
    mpz_pow_ui(res.get_mpz_t(), n.get_mpz_t(), 2);
    res=res*205+250*n+77;
  }
}

void baseb(mpf_class n, mpz_class &res) {
  res=1;
}

void basep(mpz_class n, mpz_class &res) {
  if(n==0) 
    res=1;
  else {
    mpz_pow_ui(res.get_mpz_t(), n.get_mpz_t(), 5);
    res=-1*res;
  }
}

void baseq(mpz_class n, mpz_class &res) {
  res=2*n+1;
  mpz_pow_ui(res.get_mpz_t(), res.get_mpz_t(), 5);
  res=32*res;
}


void binsplit(struct abpq_series_result &r, int n1, int n2)
{
  struct abpq_series_result s,t;
  mpz_class gcd;
  int i, diff;
  diff=n2-n1;
  if(diff==0) 
    printf("sum_abpq: n2-n1 should be >0.\n");
  else if (diff<=5) {
    for(i=0;i<diff;i++) {
      basep(n1+i, t.P);
      baseq(n1+i,t.Q);
      baseb(n1+i,t.B);
      basea(n1+i, t.T);
      t.T=t.T * t.P;
      //now merge
      if(i==0) {
	s=t;
	r=s;
      }else{
	//merge
	r.P=s.P*t.P;
	r.Q=s.Q*t.Q;
	r.B=s.B*t.B;
	//GCD OPERATION GODES HERE
 	mpz_gcd(gcd.get_mpz_t(), r.P.get_mpz_t(), r.Q.get_mpz_t());
 	mpz_gcd(gcd.get_mpz_t(), gcd.get_mpz_t(), r.B.get_mpz_t());
 	r.P=r.P/gcd;
 	r.Q=r.Q/gcd;
 	r.B=r.B/gcd;

	r.T=t.B*t.Q*s.T + s.B*s.P*t.T;
	s=r;
      }
    }
  }else {
    int nm=(n1+n2)/2;
    binsplit(s, n1, nm);
    binsplit(t, nm, n2);

    r.P=s.P * t.P;
    r.Q=s.Q * t.Q;
    r.B=s.B * t.B;
    r.T=t.B * t.Q * s.T + s.B * s.P * t.T;
    
  }
}


void post_binsplit(mpz_class S, unsigned long prec, mpz_class &pi) {
  pi=S/2;
}

void final_div(struct abpq_series_result r, unsigned long digits, mpz_class &S) {
  mpz_class BQ, T;

  mpz_class B, Q;
  B=r.B;
  Q=r.Q;
  mpz_mul(BQ.get_mpz_t(), B.get_mpz_t(), Q.get_mpz_t());
  
  T=r.T;
  B=10;
  mpz_pow_ui(Q.get_mpz_t(), B.get_mpz_t(), digits); //Q holds 10^digits
  mpz_mul(T.get_mpz_t(), T.get_mpz_t(), Q.get_mpz_t()); //T holds T*(10^digits)
  mpz_fdiv_q(S.get_mpz_t(), T.get_mpz_t(), BQ.get_mpz_t());


}



int inc_stacksize(void) {
  struct rlimit limit;
  int ret;
  if(getrlimit(RLIMIT_STACK, &limit)<0) {
    printf("getrlimit error\n");
    return -1;
  }
  limit.rlim_cur=RLIM_INFINITY;
  limit.rlim_max=RLIM_INFINITY;
  ret=setrlimit(RLIMIT_STACK, &limit);
  printf("setrlimit=%d\n", ret);
  return 0;
}

int checkIn(struct abpq_series_result &r, int &n1, int &n2) {
  //checkIn is disabled
  return -1;


  FILE *fp;
  mpz_class p;
  char c;
  if((fp=fopen("zeta.save", "r"))==NULL)
    return -1;
  printf("Do you want to reuse the saved result?(y/n)");
  cin>>c;
  if(c=='n')
    return -1;
  else {
    mpz_inp_raw(p.get_mpz_t(), fp);
    n1=mpz_get_ui(p.get_mpz_t());
    mpz_inp_raw(p.get_mpz_t(), fp);
    n2=mpz_get_ui(p.get_mpz_t());

    mpz_inp_raw(r.P.get_mpz_t(), fp);
    mpz_inp_raw(r.Q.get_mpz_t(), fp);
    mpz_inp_raw(r.B.get_mpz_t(), fp);
    mpz_inp_raw(r.T.get_mpz_t(), fp);
  }
  fclose(fp);
  return 0;
}

void checkOut(struct abpq_series_result r, int n1, int n2){
  FILE *fp;
  mpz_class p;
  fp=fopen("zeta.save", "w");
  p=n1;
  cout<<"saving n1:"<<p;
  mpz_out_raw(fp, p.get_mpz_t());
  p=n2;
  cout<<"\tn2:"<<p<<endl;
  mpz_out_raw(fp, p.get_mpz_t());
  mpz_out_raw(fp, r.P.get_mpz_t());
  mpz_out_raw(fp, r.Q.get_mpz_t());
  mpz_out_raw(fp, r.B.get_mpz_t());
  mpz_out_raw(fp, r.T.get_mpz_t());
  
}

void merge(struct abpq_series_result &p, struct abpq_series_result q){
  p.P=p.P * q.P;
  p.Q=p.Q * q.Q;
  p.B=p.B * q.B;
  p.T=q.B * q.Q * p.T + p.B * p.P * q.T;
}

int main(int argc, char *argv[]) {
  if(argc!=2) {
    printf("Please enter the number of digits desired.\n");
    exit(1);
  }
  FILE *stats;
  stats=fopen("zeta.stats", "a");

  fprintf(stats, "=====================================\n");
  inc_stacksize();
  int digits, n1, n2;
  digits=atoi(argv[1]);
  n1=0;
  n2=(int)(ceil(digits/DIGITS_PER_TERM));
  mpz_class S,pi;
  int reuse;
  struct abpq_series_result r,s;

  clock_t begin, end, t1, t2;
  t1=clock();

  fprintf(stats, "Time profile for: %d digits, %d terms\n", digits, n2);
  
  //saved file has:
  //1. n1, n2
  //2. P,Q,B,T
  int n3, n4;
  if((reuse=checkIn(s, n3, n4))==0) {
    if(n4>=n2) {//then we skip bin split and just do the division
      printf("you're skippin bin split totally!\n");
    }else{
      n1=n4;
      binsplit(r, n1, n2);
      merge(r, s);
      printf("you computed the new half(%d, %d) and merged!\n", n1, n2);
    }      
  }else {
    //here we do the bin split
    binsplit(r,n1,n2);
    printf("i'm computing binsplit all over again\n");
  }  
  
//   begin=clock();
//   binsplit(r, n1, n2);
//   end=clock();
//   fprintf(stats,"binsplit:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);

  //reporting number of digits of T,B,Q
  fprintf(stats,"Number of digits:\n");
  fprintf(stats, "\tT:%d\n\tB:%d\n\tQ:%d\n", mpz_sizeinbase(r.T.get_mpz_t(), 10),\
	  mpz_sizeinbase(r.B.get_mpz_t(), 10), mpz_sizeinbase(r.Q.get_mpz_t(), 10));
  
  //we dump the T,B,P,Q values here
//   cout<<"T:="<<r.T<<";"<<endl;
//   cout<<"Q:="<<r.Q<<";"<<endl;
  checkOut( r, n1,  n2);

  printf("hello, digits=%d\n", digits);
  begin=clock();
  final_div(r,digits, S); 
  end=clock();
  fprintf(stats, "final_div:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);


  begin=clock();
  post_binsplit(S, (int)(ceil(BITS_PER_DIGIT*digits)), pi);
  end=clock();
  fprintf(stats,"post_binsplit:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);
  
  begin=clock();
  FILE *fp;
  strcat(argv[1], ".zeta");
  fp=fopen(argv[1], "w");
  

  mpz_out_str(fp, 10, pi.get_mpz_t());
  fprintf(fp, "\n");
  end=clock();
  fprintf(stats, "mpf_out_str:%.2f secs\n", (double)(end-begin)/CLOCKS_PER_SEC);
  fclose(fp);
  t2=clock();
  
  fprintf(stats,"Total Time: %.2f secs\n", (double)(t2-t1)/CLOCKS_PER_SEC);
  fprintf(stats, "=====================================\n");

  return 0;
}










