#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
  if(argc!=3) {
    printf("2 files needed\n");
    exit(1);
  }
  int p;
  char c1, c2;
  FILE *fp1, *fp2;
  fp1=fopen(argv[1], "r");
  fp2=fopen(argv[2], "r");
  p=0;
  while((c1=fgetc(fp1))!=EOF && (c2=fgetc(fp2))!=EOF) {
    if(c1!=c2)
      break;
    else
      p++;
  }
  printf("\t%d chars\n", p);
  return 0;
  
}

