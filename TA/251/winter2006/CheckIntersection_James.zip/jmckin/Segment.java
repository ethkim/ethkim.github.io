/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * Partially implements a segment
 */
public class Segment implements Comparable {
	// the first and second points
	public Point p1;
	public Point p2;
	
	/**
	 * Creates a new segment with the given points
	 * 
	 * @param x1 the x coordinate of the first point
	 * @param y1 the y coordinate of the first point
	 * @param x2 the x coordinate of the second point
	 * @param y2 the y coordinate of the second point
	 */
	public Segment(double x1, double y1, double x2, double y2) {
		// create two temporary points for comparison
		Point a = new Point(x1, y1);
		Point b = new Point(x2, y2);
		
		// put the leftmost point first
		if (a.compareTo(b) <= 0) {
			p1 = new Point(a, Point.LEFT, this);
			p2 = new Point(b, Point.RIGHT, this);
		} else {
			p1 = new Point(b, Point.LEFT, this);
			p2 = new Point(a, Point.RIGHT, this);
		}
	}
	
	/**
	 * Returns true if the segment intersects with another segment
	 * Book page 937
	 * 
	 * @param s the other segment
	 * @return true if segments intersect, and false otherwise
	 */
	public boolean intersect(Segment s) {
		double d1 = Point.direction(s.p1, s.p2, p1);
		double d2 = Point.direction(s.p1, s.p2, p2);
		double d3 = Point.direction(p1, p2, s.p1);
		double d4 = Point.direction(p1, p2, s.p2);
		
		if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && 
			((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0)))
			return true;
		else if (d1 == 0 && p1.onSegment(s))
			return true;
		else if (d2 == 0 && p2.onSegment(s))
			return true;
		else if (d3 == 0 && s.p1.onSegment(this))
			return true;
		else if (d4 == 0 && s.p2.onSegment(this))
			return true;
		
		return false;
	}
	
	/**
	 * Compares this segment to another segment
	 * Based on the diagrams page 938
	 * 
	 * If this segment is above the other, return 1
	 * If this segment is below the other, return -1
	 * If neither, return 0 (should never occur)
	 * 
	 * @param o the other segment
	 */
	public int compareTo(Object o) {
		Segment s = (Segment) o;
		
		// the test below only works if this segment starts before the other segment,
		// so do the reverse comparison and negate the answer if that is not the case
		if (p1.x < s.p1.x) return -s.compareTo(this);
		
		// one vector
		Point a = s.p1.vectorTo(p1);
		// another vector
		Point b = s.p1.vectorTo(s.p2);
		
		// calculate cross product
		double x = a.crossProduct(b);
		
		// if negative, point is above segment
		if (x < 0) return 1;
		// if positive, point is below segment
		if (x > 0) return -1;
		return 0;
	}
	
	/**
	 * For debugging
	 */
	public String toString() {
		return "[" + p1.toString() + ", " + p2.toString() + "]";
	}
}