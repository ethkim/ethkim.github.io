/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
import java.io.*;

/**
 * Class that determines whether any pair of segments intersects
 * 
 * Contains a main method that runs from the command line
 * By default, it uses the file 'segments.dat' from the current working 
 * directory as the list of line segments.  If args[0] is defined, it is 
 * used as the filename of the list of line segments.
 * 
 * Outputs 'Intersection found' or 'No intersection found'
 */
public class CheckIntersections {
	/**
	 * @param list of endpoints in a min-heap
	 * @return true if any segments intersect, and false otherwise
	 */
	public static boolean anySegmentsIntersectList(MinHeap Points) {
		SortedLinkedList List = new SortedLinkedList();
		
		// the endpoints of the segments in S are almost sorted, since
		// they are stored in a min-heap. We need only extract them!
		
		while (!Points.isEmpty()) {
			// extract the point
			Point p = (Point) Points.extractMin();
			// if p is the left endpoint of a segment
			if (p.end == Point.LEFT) {
				// insert the segment into the list
				Object s = List.insert(p.segment);
				
				// get the segments above and below
				Object a = List.successor(s);
				Object b = List.predecessor(s);
				
				// if a exists and intersects the segment,
				// or b exists and intersects the segment
				if ((!List.isNil(a) && p.segment.intersect((Segment) SortedLinkedList.dereference(a))) ||
					(!List.isNil(b) && p.segment.intersect((Segment) SortedLinkedList.dereference(b)))) {
					return true;
				}
			// if p is the right endpoint of a segment
			} else {
				// find the segment in the list
				Object s = List.search(p.segment);
				
				// get the segments above and below
				Object a = List.successor(s);
				Object b = List.predecessor(s);
				
				// if both a and b exist and intersect
				if (!List.isNil(a) && !List.isNil(b) && ((Segment) SortedLinkedList.dereference(a)).intersect((Segment) SortedLinkedList.dereference(b))) {
					return true;
				}
				
				// delete the segment from the list
				List.delete(s);
			}
		}
		
		return false;
	}
	
	/**
	 * @param list of endpoints in a min-heap
	 * @return true if any segments intersect, and false otherwise
	 */
	public static boolean anySegmentsIntersectTree(MinHeap Points) {
		RedBlackTree Tree = new RedBlackTree();
		
		// the endpoints of the segments in S are almost sorted, since
		// they are stored in a min-heap. We need only extract them!
		
		while (!Points.isEmpty()) {
			Point p = (Point) Points.extractMin();

			// if p is the left endpoint of a segment
			if (p.end == Point.LEFT) {
				// insert the segment into the tree
				Object s = Tree.insert(p.segment);
				
				// get the segments above and below
				Object a = Tree.successor(s);
				Object b = Tree.predecessor(s);
				
				// if a exists and intersects the segment,
				// or b exists and intersects the segment
				if ((!Tree.isNil(a) && p.segment.intersect((Segment) RedBlackTree.dereference(a))) ||
					(!Tree.isNil(b) && p.segment.intersect((Segment) RedBlackTree.dereference(b)))) {
					return true;
				}
			// if p is the right endpoint of a segment
			} else {
				// find the segment in the tree
				Object s = Tree.search(p.segment);
				
				// get the segments above and below
				Object a = Tree.successor(s);
				Object b = Tree.predecessor(s);
				
				// if both a and b exist and intersect
				if (!Tree.isNil(a) && !Tree.isNil(b) && ((Segment) RedBlackTree.dereference(a)).intersect((Segment) RedBlackTree.dereference(b))) {
					return true;
				}

				// delete the segment from the tree
				Tree.delete(s);
			}
		}
		
		return false;
	}

	/**
	 * Main loop for the program
	 * 
	 * @param args
	 * @throws IOException
	 */
    public static void main( String args[] ) throws IOException {
		// variables related to the list
    		boolean listMode = false;
    		MinHeap points = new MinHeap();

		// variables related to i/o
		String segmentsFilename = "segments2.dat";
		FileReader reader;
		BufferedReader bufferedReader;
		String newLine;
	
		// parse the command-line arguments
		for (int i = 0; i < args.length; i++)
			if (args[i].equals("-l"))
				listMode = true;
			else
				segmentsFilename = args[i];

		// open the list of segments file
		reader = new FileReader(segmentsFilename);
		bufferedReader = new BufferedReader(reader);
		
		// read file one line/segment at a time, inserting segments into the list
		while((newLine = bufferedReader.readLine()) != null) {
			// split the coordinates
			String[] c = newLine.split("\\s");
			// create a segment with those coordinates
			Segment s = new Segment(Double.parseDouble(c[0]), Double.parseDouble(c[1]), Double.parseDouble(c[2]), Double.parseDouble(c[3]));
			// add the segment's points to the list
			points.insert(s.p1);
			points.insert(s.p2);
		}
		bufferedReader.close();
		
		// determine whether any pair of segments intersects
		boolean found = (listMode) ? anySegmentsIntersectList(points) : anySegmentsIntersectTree(points);

		// print out the method
		if (listMode) System.out.println("Using a linked list");
		else System.out.println("Using a red black tree");
		
		// print out the conclusion
		if (found) System.out.println("Intersection found");
		else System.out.println("No intersection found");
    }

}
