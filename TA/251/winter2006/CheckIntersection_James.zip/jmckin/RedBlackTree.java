/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * Implements a red-black tree
 * Follows the code in the book
 */
public class RedBlackTree {
	// the colors black and red
	protected static byte BLACK = 0;
	protected static byte RED = 1;

	// the root of the tree
	private TreeNode root;
	
	// the sentinel to represent all leaves and the root's parent, see page 274
	private TreeNode nil;
	
	/**
	 * Implements a tree node
	 */
	protected class TreeNode implements Comparable {
		// the node's value
		public Comparable value;
		// the node's parent
		public TreeNode parent;
		// the node's left child
		public TreeNode left;
		// the node's right child
		public TreeNode right;
		// the node's color, either black or red
		public int color;
		
		/**
		 * Constructor for the TreeNode class
		 * 
		 * @param x the node's value
		 */
		public TreeNode (Comparable x) {
			value = x;
			parent = nil;
			left = nil;
			right = nil;
			// new nodes start red
			color = RED;
		}
		
		/**
		 * Compares this node to another node
		 * 
		 * @param n the other node
		 * @return  negative if this node is less than n, positive
		 * 			if this node is greater than n, and 0 if this
		 * 			node equals n
		 */
		public int compareTo(Object n) {
			return value.compareTo(((TreeNode) n).value);
		}
		
		/**
		 * For debugging
		 */
		public String toString() {
		    if (this == nil)
				return "nil" + ", " + (color == RED ? "red" : "black");
			else
				return value.toString() + ", " + (color == RED ? "red" : "black");
		}
		
		public String toString(int depth) {
		    String result = "";

		    if (left != nil)
		    		result += left.toString(depth + 1);

		    for (int i = 0; i < depth; i++)
		    		result += "  ";

		    result += toString() + "\n";

		    if (right != nil)
		    		result += right.toString(depth + 1);

		    return result;
		}
	}
	
	/**
	 * Sets the sentinel to a node, and makes the sentinal black
	 * 
	 * @param n the node
	 */
	private void setNil(TreeNode n) {
		nil = n;
		nil.parent = nil;
		nil.left = nil;
		nil.right = nil;
		nil.color = BLACK;
	}
	
    /**
     * @param x the node that is being asked about
     * @return true if the node is the sentinel and false otherwise
     */
    public boolean isNil(Object x) {
    		return x == nil;
    }
	
	/**
	 * Constructor for the RedBlackTree class
	 * 
	 * Creates a tree with just nil as the root
	 */
	public RedBlackTree() {
		// set the root of tree to an empty black node
		setNil(new TreeNode(null));
		root = nil;
	}

	/**
	 * Performs a left rotation on a node 
	 * Book page 278
	 * 
	 * @param x the node
	 */
	private void leftRotate(TreeNode x) {
		TreeNode y = x.right;

		if (y == nil) throw new TreeException("Can't leftRotate if right child is nil!");

		// turn y's left subtree into x's right subtree
		x.right = y.left;
		if (y.left != nil)
			y.left.parent = x;

		// link y to x's parent
		y.parent = x.parent;

		// if x is the root of the entire tree, make y the root
		if (x.parent == nil)
		    root = y;
		// otherwise, make y the correct child of y's ex-parent
		else
			if (x == x.parent.left)
				x.parent.left = y;
			else
				x.parent.right = y;

		// put x on y's left
		y.left = x;
		x.parent = y;
	}
	
	/**
	 * Performs a right rotation on a node
	 * Mirror of above
	 * 
	 * @param x the node
	 */
	private void rightRotate(TreeNode x) {
		TreeNode y = x.left;

		if (y == nil) throw new TreeException("Can't rightRotate if left child is nil!");

		// turn y's right subtree into x's left subtree
		x.left = y.right;
		if (y.right != nil)
			y.right.parent = x;

		// link y to x's parent
		y.parent = x.parent;
		
		// if x is the root of the entire tree, make y the root
		if (x.parent == nil)
		    root = y;
		// otherwise, make y the correct child of y's ex-parent
		else
			if (x == x.parent.right)
				x.parent.right = y;
			else
				x.parent.left = y;

		// put x on y's right
		y.right = x;
		x.parent = y;
	}

	/**
	 * Inserts a new object into the RedBlackTree
	 * Book page 280
	 * 
	 * @param a the object to insert
	 * @return a reference to the new tree node 
	 */
	public Object insert(Comparable a) {
		// create the new tree node object
		TreeNode z = new TreeNode(a);
		
		// y is the parent of x
		TreeNode y = nil;
		// x traces a path down the tree
		TreeNode x = root;

		// while x is not a leaf
		while (x != nil) {
			// update y
		    y = x;
		    // if the key to insert is less than this node's key, go down the left side
		    if (z.compareTo(x) < 0)
		    		x = x.left;
		    // otherwise, go down the right side
		    else
		    		x = x.right;
		}

		// z's parent is x's parent
		z.parent = y;
		
		// if the tree had been empty, make z the root
		if (y == nil)
		    root = z;
		else
			// if the key to insert is less than its parent's key, it is the left child
		    if (z.compareTo(y) < 0)
		    		y.left = z;
		    // otherwise, it is the right child
		    else
		    		y.right = z;
		
		// restore the red-black properties of the tree
		insertFixup(z);
		
		return z;
	}
	
	/**
	 * Restores the red-black properties of the tree
	 * Book page 281
	 * See book for case-by-case explanation
	 * 
	 * @param z the new node
	 */
	private void insertFixup(TreeNode z) {
		TreeNode y = nil;

		while (z.parent.color == RED) {
		    if (z.parent == z.parent.parent.left) {
				y = z.parent.parent.right;
				if (y.color == RED) {
				    z.parent.color = BLACK;
				    y.color = BLACK;
				    z.parent.parent.color = RED;
				    z = z.parent.parent;
				} else {
				    if (z == z.parent.right) {
						z = z.parent;
						leftRotate(z);
				    }
				    
				    z.parent.color = BLACK;
				    z.parent.parent.color = RED;
				    rightRotate(z.parent.parent);
				}
		    } else {
				y = z.parent.parent.left;
				if (y.color == RED) {
				    z.parent.color = BLACK;
				    y.color = BLACK;
				    z.parent.parent.color = RED;
				    z = z.parent.parent;
				} else {
				    if (z ==  z.parent.left) {
						z = z.parent;
						rightRotate(z);
				    }
				    
				    z.parent.color = BLACK;
				    z.parent.parent.color = RED;
				    leftRotate(z.parent.parent);
				}
		    }
		}
		
		root.color = BLACK;
	}
	
	/**
	 * Deletes a node from the RedBlackTree
	 * Page 288
	 *
	 * @param a the object to delete
	 */
    public void delete(Object a) {
        // the node to delete
        TreeNode z = (TreeNode) a;
        // x or y is the node to replace z
        TreeNode x = nil;
        TreeNode y = nil;
        
        if (z == nil) throw new TreeException("Can't delete nil!");

        // if one of z's children is nil, the other child will replace z
        if (z.left == nil || z.right == nil)
        	y = z;
        // otherwise, z's successor will replace z
        else
            y = (TreeNode) successor(z);

        // if one of z's children was nil above, get the other child to replace z
        // if z's successor was found above, get the child to replace z's successor
        if (y.left != nil)
            x = y.left;
        else
            x = y.right;

        // link x to y's parent
        x.parent = y.parent;
        
        // if y is the root of the entire tree, make x the root
        if (y.parent == nil)
            root = x;
        // otherwise, make x the correct child of y's ex-parent
        else
            if (y == y.parent.left)
            		y.parent.left = x;
            else
            		y.parent.right = x;
        
        // copy y's satellite data into z
        if (y != z) 
        		z.value = y.value;
        
        // if y is black, restore the red-black properties of the tree
        if (y.color == BLACK)
            deleteFixup(x);
}

	/**
	 * Restores the red-black properties of the tree
	 * Book page 289
	 * See book for case-by-case explanation
	 *
	 * @param x the deleted node's sole child, or the sentinel
	 */
	private void deleteFixup(TreeNode x) {
		while (x != root && x.color == BLACK) {
			if (x == x.parent.left) {
				TreeNode w = x.parent.right;
	
				if (w.color == RED) {
					w.color = BLACK;
					x.parent.color = RED;
					leftRotate(x.parent);
					w = x.parent.right;
				}

				if (w.left.color == BLACK && w.right.color == BLACK) {
					w.color = RED;
					x = x.parent;
				} else {
					if (w.right.color == BLACK) {
						w.left.color = BLACK;
						w.color = RED;
						rightRotate(w);
						w = x.parent.right;
					}
					
					w.color = x.parent.color;
					x.parent.color = BLACK;
					w.right.color = BLACK;
					leftRotate(x.parent);
					x = root;
				}
            } else {
	            	TreeNode w = x.parent.left;
	
	            	if (w.color == RED) {
	            		w.color = BLACK;
	            		x.parent.color = RED;
	            		rightRotate(x.parent);
	            		w = x.parent.left;
	            	}
	
	            	if (w.right.color == BLACK && w.left.color == BLACK) {
	            		w.color = RED;
	            		x = x.parent;
	            	} else {
	            		if (w.left.color == BLACK) {
	            			w.right.color = BLACK;
	            			w.color = RED;
	            			leftRotate(w);
	            			w = x.parent.left;
	            		}
	
	            		w.color = x.parent.color;
	            		x.parent.color = BLACK;
	            		w.left.color = BLACK;
	            		rightRotate(x.parent);
	            		x = root;
	            	}
            }
        }

		x.color = BLACK;
	}
	
    /**
     * Searches the tree for a node with a given value
     *
     * @param k the value being searched for
     * @return 	A reference to the node with value k if it exists, 
     * 			or a reference to the sentinel if not
     */
    public Object search(Comparable k) {
	    	TreeNode x = root;
	    	int c;
	    	
	    	while (x != nil && (c = k.compareTo(x.value)) != 0) {
	    		if (c < 0)
	    			x = x.left;
	    		else
	    			x = x.right;
	    	}
	
	    	return x;
    }
    
	/**
	 * Returns a node's successor if it exists and nil otherwise
	 * Book page 259
	 * 
	 * @param x the node
	 * @return the node's successor
	 */
	public Object successor(Object node) {
		TreeNode x = (TreeNode) node;
		
		// if x's right subtree is not empty, find the leftmost node in the right subtree 
		if (x.right != nil)
			return minimum(x.right);

		// otherwise, find the lowest ancestor of x whose left child is also an ancestor of x
		TreeNode y = x.parent;
		// while the lowest ancestor of x's left child is not also an ancestor of x
		while (y != nil && x == y.right) {
			// climb up the tree
			x = y;
			y = y.parent;
		}
		
		return y;
	}
	
    /**
     * Returns a node's predecessor if it exists and nil otherwise
     * Mirror of above 
     * 
     * @param x the node
     * @return the node's predecessor
     */
    public Object predecessor(Object node) {
    		TreeNode x = (TreeNode) node;

    		// if x's left subtree is not empty, find the rightmost node in the left subtree 
		if (x.left != nil)
		    return maximum(x.left);
	
		// otherwise, find the lowest ancestor of x whose right child is also an ancestor of x
		TreeNode y = x.parent;
		// while the lowest ancestor of x's right child is not also an ancestor of x
		while (y != nil && x == y.left) {
			// climb up the tree
		    x = y;
		    y = y.parent;
		}
	
		return y;
    }
	
	/**
	 * Returns the leftmost node in the subtree rooted at a node
	 * Book page 258
	 * 
	 * @param x the node
	 * @return the subtree's minimum 
	 */
	private Object minimum(TreeNode x) {
		// climb down the left side of the tree
		while (x.left != nil)
			x = x.left;

		return x;
	}
	
	/**
	 * Returns the rightmost node in the subtree rooted at a node
	 * Book page 258
	 * 
	 * @param x the node
	 * @return the subtree's maximum 
	 */
	private Object maximum(TreeNode x) {
		// climb down the right side of the tree
		while (x.right != nil)
			x = x.right;

		return x;
	}
	
    /**
     * Returns the data stored in a node
     *
     * @param x the node
     */
    public static Comparable dereference(Object x) {
    		return ((TreeNode) x).value;
    }
    
    /**
     * For debugging
     */
    public String toString() {
    		return root.toString(0);
    }
}