/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
import java.util.Iterator;

// Re-used code from COMP-250, with modifications and refactoring

/**
 * Implements a doubly-linked list
 */
public class LinkedList {
	// the sentinel
    protected Node nil;
	
	/**
	 * Implements a node
	 */
	protected static class Node implements Comparable {
		// the node's value
		public Comparable value;
		// a reference to the previous node in the list
		public Node prev;
		// a reference to the next node in the list
		public Node next;
		
		/**
		 * Contructor for the Node class
		 */
		public Node() {
			value = null;
			prev = null;
			next = null;
		}
		
		/**
		 * Contructor for the Node class storing an object
		 */
		public Node(Comparable x) {
			value = x;
			prev = null;
			next = null;
		}
		
		/**
		 * Compares this node to another node
		 * 
		 * @param o the other node
		 * @return 	negative if this Node is less than n, positive
		 * 			if this Node is greater than n, and 0 if this
		 * 			Node equals n
		 */
		public int compareTo(Object o) {
			return value.compareTo(((Node) o).value);
		}
	}
	
	/**
	 * Implements a linked list iterator
	 */
	public class ListIterator implements Iterator {
		// the current node
		private Node current;
		
		/**
		 * Constructor for the LinktIterator class
		 */
		public ListIterator() {
			current = nil;
		}
		
		/**
		 * Determines if the iterator has more elements or not
		 * 
		 * @return true if iterator has more elements, and false otherwise
		 */
		public boolean hasNext() {
			return current.next != nil;
		}
		
		/**
		 * Returns the next element in the iteration
		 * 
		 * @return the next element
		 */
		public Object next() {
			current = current.next;
			return current.value;
		}
		
		public void remove() {
			// I don't need this method
		}
	}
	
    /**
     * @param x the node that is being asked about
     * @return true if the node is the sentinel, and false otherwise
     */
    public boolean isNil(Object x) {
    		return x == nil;
    }
    
    /**
     *  Constructor for the LinkedList class 
     */ 
    public LinkedList() {
    	// create the sentinal and make it a circular list
        nil = new Node();
        nil.prev = nil;
        nil.next = nil;
    }

    /**
     * Inserts an object at the head of the LinkedList
     * 
     * @param x the object to insert
     * @return a reference to the new node
     */ 
    public Object insert(Comparable o) {
	    	Node x = new Node(o);
	    	// link x to its successor
	    	x.next = nil.next;
	    	nil.next.prev = x;
	    	// link x to its predecessor
	    	nil.next = x;
	    	x.prev = nil;
	    	return x;
    }

    /**
    * Deletes a node from the LinkedList
    *
    * @param a the object to delete
    */
    public void delete(Object a)
	{
    		Node x = (Node) a;
    		// link x's neighbors
		x.prev.next = x.next;
		x.next.prev = x.prev;
		// clear x's links
		x.prev = null;
		x.next = null;
	}
   
    /**
     * Determines if an object is in the LinkedList or not
     *
	 * @param o the object to check
     * @return true if the object is present, and false otherwise
     */
    public boolean contains(Comparable o) {
		// traverse the linked list 
        Node x = nil.next;
        while (x != nil && x.value.compareTo(o) != 0)
        		x = x.next;

        // if found, return true
        return (x != nil);
    }
    
    /**
     * Searches the list for a node with a given value
     *
     * @param o the value being searched for
     * @return 	A reference to the node with value k if it exists, 
     * 			or a reference to the sentinel if not
     */
    public Object search(Comparable o) {
		// traverse the linked list 
        Node x = nil.next;
        while (x != nil && x.value.compareTo(o) != 0)
        		x = x.next;

        // if found, return reference
        if (x == nil)
        		return null;
        else
        		return x;
    }

    /**
	 * Returns the number of elements in the LinkedList
	 * 
	 * @return the number of elements
	 */
	public int size() {
		// initialize the size counter
        int s = 0;

        // traverse the linked list
		Node x = nil.next;
        while (x != nil) {
            x = x.next;
            // increment the size counter
            s++;
        }

        return s;
	}
	
	/**
	 * Creates and returns an Iterator for this list
	 * 
	 * @return the iterator
	 */
	public Iterator iterator() {
		return new ListIterator();
	}
	
    /**
     * Returns the data stored in a node
     *
     * @param x the node.
     */
    public static Object dereference(Object x) {
    		return ((Node) x).value;
    }
}