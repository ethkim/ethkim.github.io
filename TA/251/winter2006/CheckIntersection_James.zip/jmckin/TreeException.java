/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
public class TreeException extends RuntimeException {
	static final long serialVersionUID = 1L;
	
	public TreeException(String s) {
		super(s);
	}
}