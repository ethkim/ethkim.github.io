/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * Implements a sorted doubly-linked list
 */
public class SortedLinkedList extends LinkedList {
	/**
	 * Constructor for the SortedLinkedList class 
	 */
	public SortedLinkedList() {
		super();
	}
	
	/**
	 * Inserts an object in order
	 *
     * @param a the object to insert
     * @return a reference to the new node
	 */
	public Object insert(Comparable o) {
		// y traverses the list
		Node y = nil.next;
		while (y != nil && o.compareTo(y.value) > 0)
			y = y.next;

		// insert o before the first value that is greater than it
		Node predecessor = y.prev;
	    Node x = new Node(o);

	    // link x to its successor
	    x.next = predecessor.next;
	    predecessor.next.prev = x;
	    // link x to its predecessor
	    predecessor.next = x;
	    x.prev = predecessor;
	    return x;
	}
    
	/**
	 * Returns a node's successor if it exists and nil otherwise
	 * 
	 * @param x the node
	 * @return the node's successor
	 */
    public Object successor(Object node) {
    	return ((Node) node).next;
    }
    
	/**
	 * Returns a node's predecessor if it exists and nil otherwise
	 * 
	 * @param x the node
	 * @return the node's predecessor
	 */
    public Object predecessor(Object node) {
    	return ((Node) node).prev;
    }
}