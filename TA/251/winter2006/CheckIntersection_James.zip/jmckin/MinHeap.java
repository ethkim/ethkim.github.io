/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * Partially implements a min-heap priority queue
 */
public class MinHeap {
    // the array holding the heap
    private Comparable[] Heap;
    // the number of elements in the heap
    private int Size;
	
    /**
     * Implements a heap node
     */
    protected static class Handle implements Comparable
    {
		// the node's value
		public Comparable value;
		// the node's index into the heap array
		public int index;

		/**
		 * Constructor for the Handle class
		 *
		 * @param i the node's index
		 * @param x the node's value
		 */
		protected Handle(int i, Comparable x)
		{
		    value = x;
		    index = i;
		}
	
		/**
		 * Compares this node to another
		 *
		 * @param o the other node
		 * @return 	negative if this Node is less than n, positive
		 * 			if this Node is greater than n, and 0 if this
		 * 			Node equals n
		 */
		public int compareTo(Object o)
		{
		    return value.compareTo(((Handle) o).value);
		}
    }

    /**
     * Constructor for the MinHeap class
     *
     */
	public MinHeap() {
		Heap = null;
		Size = 0;
	}
	
    /**
     * Swaps the elements at two indices
     *
     * @param i one index
     * @param j the other index
     */
    protected void exchange(int i, int j)
    {
		((Handle) Heap[i]).index = j;
		((Handle) Heap[j]).index = i;
		Comparable c = Heap[i];
		Heap[i] = Heap[j];
		Heap[j] = c;
    }

    /**
     * Gets the index of a node's parent
     * Book page 128 
     * @param i the node
     */
    public static int parent(int i)
    {
    		return (i - 1) / 2;
    }

    /**
     * Gets the index of a node's left child
     * Book page 128 
     * @param i the node
     */
    public static int left(int i)
    {
    		return 2 * i + 1;
    }

    /**
     * Gets the index of a node's right child
     * Book page 128 
     * @param i the node
     */
    public static int right(int i)
    {
    		return 2 * i + 2;
    }

    /**
     * @return true if the heap is empty, false otherwise
     */
    public boolean isEmpty()
    {
    		return Size < 1;
    }
    
    /**
     * Inserts a new object into the min-heap
     * Book page 140
     *
     * @param x the object to insert
     * @return a reference to the new heap node
     */
    public Object insert(Comparable x)
    {
		// if the array doesn't yet exist, create it
		if (Heap == null) {
		    Heap = new Comparable[1];
		    Size = 0;
		}
		
		// If there's not enough room for the new element, double the array size
		else if (Size >= Heap.length) {
		    Comparable[] T = new Comparable[Size * 2];
	
		    for (int i = 0; i < Size; i++)
		    		T[i] = Heap[i];
	
		    Heap = T;
		}
	
		// create a new node and put it in the next available index
		Handle node = new Handle(Size, x);
		Heap[Size] = node;
		Size++;
	
		// bubble it up the heap
		bubbleUp(Size - 1);
	
		return node;
    }

    /**
     * Deletes and returns the smallest element in the min-heap
     * Book page 139
     * 
     * @return a reference to the deleted heap node
     */
    public Comparable extractMin()
    {
		// Get a reference to the smallest element.
		Comparable min = ((Handle) Heap[0]).value;
	
		// move the last element in the heap to the root, and clear
		// out the reference in its current array position
		Heap[0] = Heap[Size - 1];
		((Handle) Heap[0]).index = 0;
		Heap[Size - 1] = null;
		Size--;
	
		// Restore the min-heap property.
		heapFixup(0);
	
		return min;
    }
    
    /**
     * Bubbles the element at a given index up in the heap
     * until it is greater than or equal to its parent
     * Book page 140
     *
     * @param i index of the element to bubble up
     */
    private void bubbleUp(int i)
    {
		while (i > 0 && Heap[parent(i)].compareTo(Heap[i]) > 0) {
		    exchange(i, parent(i));
		    i = parent(i);
		}
    }
    
    /**
     * Restores the min-heap property, assuming that the min-heap 
     * property holds everywhere, with the possible exception of 
     * one position and its children
     * Book page 130
     *
     * @param i index at which the min-heap property might not hold
     */
    public void heapFixup(int i)
    {
		int l = left(i);
		int r = right(i);
		int smallest = i;
		if (l < Size && Heap[l].compareTo(Heap[i]) < 0)
		    smallest = l;
		if (r < Size && Heap[r].compareTo(Heap[smallest]) < 0)
		    smallest = r;
		if (smallest != i) {
		    exchange(i, smallest);
		    heapFixup(smallest);
		}
    }
}