/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * Partially implements a point
 */
public class Point implements Comparable {
	// the ends left and right
	public static byte LEFT = 0;
	public static byte RIGHT = 1;
	
	// the point's coordinates
	public double x;
	public double y;
	// the point's end, either left or right
	public byte end;
	// the segment to which the point belongs
	public Segment segment;
	
	/**
	 * Constructor for the Point class
	 * 
	 * @param x the point's x coordinate
	 * @param y the point's y coordinate
	 * @param end the point's end, either left or right
	 * @param s the segment to which the point belongs
	 */
	public Point(double x, double y, byte end, Segment segment) {
		this.x = x;
		this.y = y;
		this.end = end;
		this.segment = segment;
	}
	
	/**
	 * Contructor for the Point class with a Point
	 * 
	 * @param p the point's coordinates
	 * @param end the point's end, left or right
	 * @param segment the segment to which the point belongs
	 */
	public Point(Point p, byte end, Segment segment) {
		this.x = p.x;
		this.y = p.y;
		this.end = end;
		this.segment = segment;
	}
	
	/**
	 * Constructor for temporary, segment-less points
	 * Used only when checking for intersections
	 * 
	 * @param x		the point's x coordinate
	 * @param y		the point's y coordinate
	 */
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
		this.end = 0;
		this.segment = null;
	}
	
	/**
	 * Subtracts another point from this point
	 * Book page 935
	 * 
	 * @param p the other point
	 * @return the difference
	 */
	public Point minus(Point p) {
		return new Point(x - p.x, y - p.y);
	}
	
	/**
	 * Returns the vector from a point to another point
	 * Book page 935
	 * 
	 * @param p the other point
	 * @return the vector
	 */
	public Point vectorTo(Point p) {
		return new Point(p.x - x, p.y - y);
	}
	
	/**
	 * Calculates the cross product of this vector and another vector
	 * Book page 935 
	 * 
	 * @param p the other vector
	 * @return the cross product
	 */
	public double crossProduct(Point p) {
		return x * p.y - p.x * y;
	}

	/**
	 * Computes the relative orientations of vectors ij and ik
	 * Book page 937, formula page 935
	 * 
	 * @param i the common point
	 * @param j one point
	 * @param k the other point
	 * @return positive if ik is clockwise from ij, and negative otherwise
	 */
	public static double direction(Point i, Point j, Point k) {
		return (k.minus(i)).crossProduct(j.minus(i));
	}
	
	/**
	 * Determines whether a point known to be collinear with a segment lies on that segment
	 * Book page 937
	 * 
	 * @param s the segment
	 * @return true if the point lies on the segment, and false otherwise
	 */
	public boolean onSegment(Segment s) {
		// true if the x coordinate is between the segment's two endpoints,
		// and the y coordinate is between the segment's two endpoints
		return (Math.min(s.p1.x, s.p2.x) <= x && x <= Math.max(s.p1.x, s.p2.x) && 
				Math.min(s.p1.y, s.p2.y) <= y && y <= Math.max(s.p1.y, s.p2.y));
	}
	
	/**
	 * Compares this endpoint to another endpoint
	 * Rules on book page 943
	 * 
	 * If this point's x coordinate is greater than the other's, return 1.
	 * If this point's x coordinate is less than the other's, return -1.
	 * If neither, break the tie by putting left endpoints first, and break 
	 * further ties by putting endpoints with lower y-coordinates first
	 * 
	 * @param o the other segment
	 */
	public int compareTo(Object o) {
		Point p = (Point) o;
		// compare x coordinates
		if (x > p.x) return 1;
		else if (x < p.x) return -1;
		else
			// break the tie with endpoint test
			if (end > p.end) return 1;
			else if (end < p.end) return -1;
			else
				// break the tie with y coordinates
				if (y > p.y) return 1;
				else if (y < p.y) return -1;
				else return 0;
	}

	/**
	 * For debugging
	 */
	public String toString() {
		return "(" + x + ", " + y + ")";
	}
}