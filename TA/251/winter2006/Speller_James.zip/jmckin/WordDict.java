/*************************************************************
* Author: James McKinney
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
import java.util.Iterator;

/**
 * Implements a dictionary
 */
public class WordDict {
	// the number of words in the dictionary
	private int Size;
	// the hash table with chaining
	private LinkedList Table[];
	// the length of the hash table
	private int Len;
    // the shift amount used
    private int shiftAmount;
    // the bit mask used
    private long bitMask;
	
	/**
	 * Constructor for the WordDict class
	 * 
	 * Should make the WordDict large enough for 50 words to start
	 */
	public WordDict() {
		// initialize the size of the dictionary
		Len = 64;
		Size = 0;
		
		// initialize the hash table
		Table = new LinkedList[Len];
		for (int i = 0; i < Len; i++)
			Table[i] = new LinkedList();
		
		// set the variables needed for hashing
		hasher();
	}
	
	/**
	 * I'm no wizard at bit manipulation, so I borrowed this from
	 * MultiplicationMethod.java on the CD that came with the book
	 * I understand how it works, I'm just not familiar with shifts
	 * and bitmasks, which has never been taught
	 */
	private void hasher() {
		// determine the lg of the table size, denoted by p
	    int p = 0;
	    int x = 1;
	    while (x < Len) {
	    		x *= 2;
	    		p++;
	    }

	    shiftAmount = 32 - p;
	    bitMask = Len - 1;
	}
	
	/**
	 * Inserts a new string into the WordDict
	 * 
	 * Ensures that the load factor never exceeds 1 by doubling the table's 
	 * length whenever the number of words exceeds the table's length
	 *  
	 * @param string the word to insert
	 * @return the number of words
	 */
	public int put(String string) {
		// increment the number of words
		Size++;
		
		// ensure that the load factor never exceeds 1 by doubling the table's 
		// length whenever the number of words exceeds the table's length
		if (Size > Len) putFixup();
		
		// insert the new string into the hash table
		// assumption: all dictionary words are distinct
		putWord(Table, string);
		
		return Size;
	}
	
	/**
	 * Doubles the length of the table
	 */
	private void putFixup() {
		// a temporary hash table
		LinkedList T[];

		// double the length of the hash table
		Len *= 2;

		// initialize the temporary hash table
		T = new LinkedList[Len];
		for (int i = 0; i < Len; i++)
			T[i] = new LinkedList();
		
		// set the variables needed for hashing
		hasher();

		// put the words in the old hash table into the temporary hash table
		for (int i = 0; i < Len / 2; i++) {
			// traverse the linked list
			Iterator iter = Table[i].iterator();
			while (iter.hasNext()) {
				// insert the word into the temporary hash table 
				putWord(T, (String) iter.next());
			}
		}

		// copy the words in the temporary hash table back into the new hash table
		Table = new LinkedList[Len];
		for (int i = 0; i < Len; i++)
			Table[i] = T[i];
	}
	
	/**
	 * Inserts a new string into the WordDict's hash table
	 * 
	 * @param table the hash table
	 * @param string the word to insert
	 */
	private void putWord(LinkedList[] table, String string) {
		// index into the hash table, and add the word to the linked list
		table[hash(string)].insert(string);
	}

	/**
	 * Determines if a string is in the WordDict or not
	 * 
	 * @param string the word to check
	 * @return true if the word is present, false otherwise
	 */
	public boolean isWord(String string) {
		// index into the hash table, determine if the word is in the 
		// linked list or not, and return true if the word is present,
		// false otherwise
		return Table[hash(string)].contains(string); 
	}
	
	/**
	 * @return the number of words in the WordDict
	 */
	public int getNumEntries() {
		return Size;
	}
	
	/**
	 * Returns statistics about the contents of the WordDict
	 * 
	 * @return the array size[], where size[j] is the number of table
	 * slots with j words for 0 <= j <= 8 and size[9] contains the 
	 * number of table slots with 9 or more words
	 */
	public int[] getStats() {
		// the size array
		int size[];
		
		// initialize the size array
		size = new int[10];
		for (int i = 0; i < 10; i++)
			size[i] = 0;
		
		// collect the statistics
		for (int i = 0; i < Len; i++) {
			// get the number of words in the current slot
			int s = Table[i].size();
			// increment the number of slots with 0 to 8 words
			if (s <= 8) size[s]++;
			// increment the number of slots with 9 or more words
			else size[9]++;
		}
		
		// return the collisions array
		return size;
	}
	
	/**
	 * Calculates the word's hash value with Fibonacci hashing
	 * Inspired from the book, page 231-232
	 * 
	 * @param string the word to hash
	 * @return the word's hash value
	 */
	private int hash(String string) {
		// express the word as a radix-31 integer
		long k = 0;
		int limit = string.length();
		for (int i = 0; i < limit; i++)
			// use Horner's rule for faster evaluation
			k = k * 31 + string.charAt(i);

		// The word size of the machine is 32 bits. So W is 2^32. Choose a constant S 
		// that is relatively prime to W and that is closest to W / phi. We choose S,
		// below, following http://www.brpreiss.com/books/opus4/html/page214.html
	    long S = 2654435769L;

		// the table size is a power of 2, so we can use the faster method on page 232
	    long r = k * S;

	    // do some shifting and bitmasking to get the most significant bits
	    return (int) ((r >> shiftAmount) & bitMask);
	}
}

