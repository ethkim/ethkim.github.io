/*************************************************************
* Author: Dorna Kashef
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * @author Dorna Kashef
 *
 *Each object if Node class has a field item which stores a string, and 
 *also has a pointer to another object of Node class.
 **/
public class Node {
  String item; // it will store a word of the dictionary.
  Node next;
  /*
   * The constructor takes a string, and stores it in the item field.
   */
  public Node(String s){
  	item=s;
  }
}
