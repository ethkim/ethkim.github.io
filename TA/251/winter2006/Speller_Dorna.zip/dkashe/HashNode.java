/*************************************************************
* Author: Dorna Kashef
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * @author Dorna Kashef
 *
 * HashNode is a class which has two fields size and next.
 */
public class HashNode {
    int size;  // size will store the number of Node objects in the linkedList that this hash node points to.
    Node next;  // next will point to a linkedList of Nodes
    public HashNode(){
    	size=0;
    }
}
