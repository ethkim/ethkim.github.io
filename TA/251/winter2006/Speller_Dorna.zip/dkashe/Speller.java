/*************************************************************
* Author: Dorna Kashef
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
import java.util.*;
import java.io.*;

/**
 * Class that implements a spelling checking
 * Contains a main method that runs from the command line
 * By default, it uses the file `words' from the current working directory as the dictionary
 * If args[0] is defined, it is used as the filename of the dictionary
 */

public class Speller {

	/**
	 * Method use to see if a collection contains an element whose string representation is the given string
	 * There is probably a clever polymorphic way to do this using list.contains(). I appreciate your suggestions.
	 * @param list	A collection to search
	 * @param str	A string to search for
	 * @return true or false depending on whether the string is in the list
	 */
	static boolean containsString( Collection list, String str ) {
		Iterator it;
		
		it = list.iterator();
		while( it.hasNext() ) 
			if( it.next().toString().equals( str ) )
				return true;
		return false;
	}
		
	/**
	 * Method that returns a list of suggested spellings for a word not in a given WordDict
	 * @param dictionary	The WordDict the contains valid spellings
	 * @param word			The word to get suggestions for
	 */
	static Collection getSuggestions( WordDict dictionary, String word ) {
		int j;
		Collection list = new LinkedList();
		StringBuffer strBuffer = new StringBuffer( word );
		String str;
		
		// Try transposing letters
		for( j = 0; j < word.length() - 1; j++ ) {
			strBuffer.setLength( 0 );
			if( j >= 1 )
				strBuffer.append( word.substring( 0, j ) );
			strBuffer.append( word.charAt( j + 1 ) );
			strBuffer.append( word.charAt( j ) );
			if( word.length() > j + 2 ) 
				strBuffer.append( word.substring( j + 2 ) );
			str = strBuffer.toString();
			if( dictionary.isWord( str ) ) 
				if( containsString( list, str ) == false )
					list.add( str );
		}
		
		// Try deleting letters
		for( j = 0; j < word.length(); j++ ) {
			strBuffer.setLength( 0 );
			if( j >= 1 )
				strBuffer.append( word.substring( 0, j ) );
			if( word.length() > j )
				strBuffer.append( word.substring( j+1 ) );
			str = strBuffer.toString();
			if( dictionary.isWord( str ) )
				if( containsString( list, str ) == false )
					list.add( str );
		}
		
		// Try inserting letters
		for( j = 0; j < word.length(); j++ ) {
			char k;
			for( k = 'a'; k <= 'z'; k++ ) {
				strBuffer.setLength( 0 );
				if( j >= 1 )
					strBuffer.append( word.substring( 0, j ) );
				strBuffer.append( k );
				if( word.length() >= j )
					strBuffer.append( word.substring( j ) );
				str = strBuffer.toString();
				if( dictionary.isWord( str ) )
					if( containsString( list, str ) == false )
						list.add( str );
			} 
		}
		return( list );
	}

	/**
	 * main loop for the spell-checking program
	 */
    public static void main( String args[] ) throws IOException {
	
		// Variables related to building the WordDict
		WordDict dictionary;
		String dictionaryFilename = "words";
		FileReader reader;
		BufferedReader bufferedReader;
		String newWord;

		// Open the dictionary file
		if( args.length > 0 )
			dictionaryFilename = args[0];
		reader = new FileReader( dictionaryFilename );
		bufferedReader = new BufferedReader( reader );
		
		// Read file one line/word at a time, inserting words into the dictionary
		dictionary = new WordDict();
		while( ( newWord = bufferedReader.readLine() ) != null )
			dictionary.put( newWord );
		bufferedReader.close();
		
		// Print out statistics about the loaded dictionary (hash table)
		System.out.println( "Dictionary size: " + dictionary.getNumEntries() );
		int[] stats = dictionary.getStats();
		for( int j = 0; j < stats.length; j++ )
			System.out.print( " " + j + " words: " + stats[j] + "\n" );

		// Variables for interactive input
		BufferedReader in = new BufferedReader( new InputStreamReader( System.in ) );
		Collection list;
		Iterator iterator;
		String inString;

		// Loop asking for input, looking up words and printing suggestions
		do {			
			System.out.print( "Enter a word or type `quit' to exit: " );
			inString = in.readLine();
			if( inString.equals( "quit" ) )
				break;
			if( dictionary.isWord( inString ) )
				System.out.println( "\"" + inString + "\" is a word." );
			else {
				list = getSuggestions( dictionary, inString );
				iterator = list.iterator();
				System.out.println( "Suggestions:" );
				while( iterator.hasNext() )
					System.out.println( " " + iterator.next() );
			}
		} while( true );
    }
}
