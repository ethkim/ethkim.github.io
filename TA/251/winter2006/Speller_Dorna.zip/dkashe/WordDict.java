/*************************************************************
* Author: Dorna Kashef
* Kindly supplied by the author, as the model solution for
* Assignment #3, CS251, Winter 2006
*************************************************************/
/**
 * A class that implements a dictionary
 */
public class WordDict {
	HashNode[] hashTable;  // hash table is an array of HashNodes
	int tableSize=0;
	int enteries=0;  // enteries keeps the number of words being added to the dictionary.
	
	/* stats will store the statistics of the hashtable.
	 *where stats[i] is the number of table slots with i words for 0 <= i <= 8 and stats[9] contains the number of table slots with 9 or more words
	*/
	int[] stats=new int[10]; 
	/**
	 * Constructor for the WordDict class
	 * It makes the hash table large enough to store 64 words without collision.
	 */
	public WordDict() {
		hashTable= new HashNode[64];
		tableSize=64;
		stats[0]=64;  // because at the beginning the hash table is empty, so all the slots have zero words in them.
	}
	
	/**
	 * Method for inserting a new string into the WordDict
	 * If the number of words before inserting the new word is equal to the size of the hashtable, 
	 * it call reHash() and then inserts the new word
	 * in order to keeping the load factor always one.
	 * @param string	the word to insert
	 * @return the number of entries in the WordDict
	 */
	public int put( String string ) {
		if(enteries>=tableSize)
			reHash();
		int code=hashCode(string);   // by calling hashCode, code stores the number of slot which the word belongs to.
		if(hashTable[code]==null){  // if this is the first word being added to this slot
			stats[0]--;   // the number of slots with no words will decrease by one.
			stats[1]++;   // the number of slots with one word will increase by one.
			hashTable[code]=new HashNode();
			hashTable[code].next=new Node(string);  // insert the string in the linkedList
			hashTable[code].size=1;
		}
		else{  // if this is not the first word being added to this slot
			int size=hashTable[code].size;
			if(size<=8){  // if the number of words in this slot is less or equal to 8.
				stats[size]--;			
				stats[size+1]++;
			}			
			hashTable[code].size++;  // increase the size of the words in this slot by one.
			// insert the word:
			Node x=new Node(string);
			x.next=hashTable[code].next;
			hashTable[code].next=x;
		}
		enteries++;  
		return enteries;
	}
		
	/**
	 * Method for determining if a string is in the WordDict or not
	 * @param string	the word to check
	 * @return true if the word is present, false otherwise
	 */
	public boolean isWord( String string ) {
		int code=hashCode(string);  // Find the slot which belongs to the hashCode of the string
		if(hashTable[code]==null) // if the slot is emoty, then the string does not exist.
			return false;
		//search through the linkedList of this slot for the string
		else{
		   Node current=hashTable[code].next;
		   while(current!=null && !string.equals(current.item))
		   	  current=current.next;
		   if(current==null)
		   	return false;
		   else
		   	return true;
		}
			
	}

	
	/**
	 * Method that returns the number of entries in the WordDict
	 * @return the number of entries
	 */
	public int getNumEntries() {
		return enteries;
	}
	
	/**
	 * Method to return statistics about the contents of the WordDict
	 * @return an int[10] array collisions[], where collisions[j] is the number of table slots with j collisions for 0 <= j <= 8 and collisions[9] contains the number of table slots with 9 or more collisions
	 */ 
	public int[] getStats() {
		return stats;
	}
	/**
	 * Method used to find the hashCode of a string.
	 * it uses the multiplication method. by using 31-radix.
	 * hashCode=floor(tableSize*(0.61803*(radix-31 code of the string) mod 1))
	 */
	public int hashCode(String s){
		double code=0;
		int radix=31;
		double A=0.61803;
		int length=s.length();
		for(int i=0;i<length;i++){
			code=(code*radix+((int)s.charAt(i))*A)%1;
		}
		return (int)Math.floor(tableSize*code);
	}
	/**
	 * Method used to reHash the words, when the number of enteries becomes more than the size of table.
	 * This method doubles the size of table, and finds the new hashCode of the elements which were already in the table,
	 * and puts them in their new slot.
	 */
	public void reHash(){
		int size=tableSize;
		tableSize*=2;
		HashNode[] prevHashTable=hashTable;
		hashTable=new HashNode[tableSize];
		for(int i=1;i<10;i++)
			stats[i]=0;
		stats[0]=tableSize;
		enteries=0;
		for(int i=0;i<size;i++){
			if(prevHashTable[i]!=null){
				Node current=prevHashTable[i].next;
				while(current!=null){
					put(current.item);
					current=current.next;
				}
			}
		}
		
	}
}


